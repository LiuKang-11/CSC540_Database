package project3;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the cancellation of a club member's membership.
 * It prompts the user for necessary information and calls a stored procedure to process the cancellation.
 */
public class CancelProcedure {

    public static void cancelMember(Scanner scanner) {
        System.out.print("StaffID: ");
        int staffID = scanner.nextInt();
        System.out.print("CustomerID: ");
        int customerID = scanner.nextInt();
        scanner.nextLine();  
        String call = "{CALL p_createCancelInfo(?, ?)}";
        try (Connection conn = Main.getConnection();
             CallableStatement cs = conn.prepareCall(call)) {

            cs.setInt(1, staffID);
            cs.setInt(2, customerID);
            cs.execute();
            System.out.println("Cancel success！");
        } catch (SQLException e) {
            System.err.println("Cancel failed：" + e.getMessage());
            e.printStackTrace();
        }
    }
}
