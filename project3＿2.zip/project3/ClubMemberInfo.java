package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the retrieval of club member information.
 * It prompts the user for a customer ID and retrieves the corresponding member's details from the database.
 */
public class ClubMemberInfo {

    // Search Clubmember
    public static void getClubMember() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input Customer ID: ");
        int customerID = scanner.nextInt();
        scanner.nextLine();  
        
        //  PreparedStatement for search
        String sql = "SELECT *" +
                     "FROM ClubMember WHERE CustomerID = ?";
        
        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setInt(1, customerID);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    System.out.println("===== Customer Info =====");
                    System.out.println("CustomerID: " + rs.getInt("CustomerID"));
                    System.out.println("FirstName: " + rs.getString("FirstName"));
                    System.out.println("LastName: " + rs.getString("LastName"));
                    System.out.println("MembershipLevel: " + rs.getString("MembershipLevel"));
                    System.out.println("Email: " + rs.getString("Email"));
                    System.out.println("PhoneNumber: " + rs.getString("PhoneNumber"));
                    System.out.println("HomeAddress: " + rs.getString("HomeAddress"));
                
                    System.out.println("=====================");
                } else {
                    System.out.println("Can't find Customer ID: " + customerID);
                }
            }
        } catch (SQLException e) {
            System.err.println("Search failed：" + e.getMessage());
            e.printStackTrace();
        }
    }
}
