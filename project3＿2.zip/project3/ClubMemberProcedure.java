package project3;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the creation of a new club member.
 * It prompts the user for necessary information and calls a stored procedure to process the creation.
 */
public class ClubMemberProcedure {

    public static void createClubMember() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("FirstName: ");
        String firstName = scanner.nextLine();
        System.out.print("LastName: ");
        String lastName = scanner.nextLine();
        System.out.print("MembershipLevel: ");
        String membershipLevel = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("PhoneNumber: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("HomeAddress: ");
        String homeAddress = scanner.nextLine();
        System.out.print("StaffID: ");
        int staffID = scanner.nextInt();
        System.out.print("StoreID: ");
        int storeID = scanner.nextInt();
        scanner.nextLine();
        
        try (Connection conn = Main.getConnection();
             CallableStatement cs = conn.prepareCall("{CALL p_createClubMemberInfo(?, ?, ?, ?, ?, ?, ?, ?)}")) {
             
            cs.setString(1, firstName);
            cs.setString(2, lastName);
            cs.setString(3, membershipLevel);
            cs.setString(4, email);
            cs.setString(5, phoneNumber);
            cs.setString(6, homeAddress);
            cs.setInt(7, staffID);
            cs.setInt(8, storeID);
            
            cs.execute();
            System.out.println("Create Customer success！");
        } catch (SQLException e) {
            System.err.println("Create Cuustomer failed：" + e.getMessage());
            e.printStackTrace();
        }
    }
}
