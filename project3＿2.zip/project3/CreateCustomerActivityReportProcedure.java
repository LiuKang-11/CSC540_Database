package project3;
import java.sql.*;
import java.math.BigDecimal;
import java.util.Scanner;
/**
 * This class handles the creation of a customer activity report.
 * It prompts the user for a date range and calls a stored procedure to generate the report.
 */
public class CreateCustomerActivityReportProcedure {
    public static void createCustomerActivityReport(Scanner scanner) {
        System.out.print("Enter start date (YYYY-MM-DD): ");
        String startInput = scanner.nextLine().trim();
        System.out.print("Enter   end date (YYYY-MM-DD): ");
        String endInput   = scanner.nextLine().trim();

        String call = "{CALL p_createCustomerActivityReport(?, ?)}";
        try (Connection conn = Main.getConnection();
             CallableStatement cs = conn.prepareCall(call)) {

            cs.setDate(1, Date.valueOf(startInput));
            cs.setDate(2, Date.valueOf(endInput));

            boolean hasRs = cs.execute();
            if (hasRs) {
                try (ResultSet rs = cs.getResultSet()) {
                    System.out.println("===== Customer Activity Report =====");
                    System.out.printf("%-12s %-15s %-15s %-20s%n",
                        "CustomerID", "FirstName", "LastName", "TotalPurchase");
                    while (rs.next()) {
                        int id      = rs.getInt("CustomerID");
                        String fn   = rs.getString("FirstName");
                        String ln   = rs.getString("LastName");
                        BigDecimal total = rs.getBigDecimal("TotalPurchaseAmount");
                        System.out.printf("%-12d %-15s %-15s %-20s%n",
                            id, fn, ln, total);
                    }
                    System.out.println("====================================");
                }
            } else {
                System.out.println("No data returned.");
            }
        } catch (SQLException e) {
            System.err.println("Failed to generate report: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
