package project3;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.math.BigDecimal;

/**
 * This class handles the generation of a customer growth report by month.
 * It calls a stored procedure to retrieve the data and prints the report.
 */
public class CreateCustomerGrowthReportByMonthProcedure {

    public static void createCustomerGrowthReportByMonth() {
        String call = "{CALL p_createCustomerGrowthReportByMonth()}";
        try (Connection conn = Main.getConnection();
             CallableStatement cs = conn.prepareCall(call)) {

            // execute
            boolean hasRs = cs.execute();
            if (hasRs) {
                try (ResultSet rs = cs.getResultSet()) {
                    System.out.println("Year\tMonth\tNewCount\tPrevCount\tGrowth\tGrowthRate(%)");
                    while (rs.next()) {
                        int year     = rs.getInt("Year");
                        int month    = rs.getInt("Month");
                        int newCnt   = rs.getInt("NewCustomerCount");
                        int prevCnt  = rs.getInt("PreviousMonthCount");
                        int growth   = rs.getInt("Growth");
                        BigDecimal rate = rs.getBigDecimal("GrowthRate");
                        String rateStr = (rate == null ? "N/A" : rate.toString());
                        
                        System.out.printf(
                            "%d\t%d\t%d\t\t%d\t\t%d\t%s%n",
                            year, month, newCnt, prevCnt, growth, rateStr
                        );
                    }
                }
            } else {
                System.out.println("No data returned by p_createCustomerGrowthReportByMonth.");
            }

        } catch (SQLException e) {
            System.err.println("Failed to generate customer growth report by month: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
