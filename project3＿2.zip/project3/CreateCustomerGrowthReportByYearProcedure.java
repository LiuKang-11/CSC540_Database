package project3;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.math.BigDecimal;

/**
 * This class handles the generation of a customer growth report by month.
 * It calls a stored procedure to retrieve the data and prints the report.
 */
public class CreateCustomerGrowthReportByYearProcedure {

    public static void createCustomerGrowthReportByYear() {
        String call = "{CALL p_createCustomerGrowthReportByYear()}";
        try (Connection conn = Main.getConnection();
             CallableStatement cs = conn.prepareCall(call)) {

            // check result
            boolean hasRs = cs.execute();
            if (hasRs) {
                try (ResultSet rs = cs.getResultSet()) {
                    System.out.println("Year\tNew\tPrev\tGrowth\tGrowthRate(%)");
                    while (rs.next()) {
                        int year           = rs.getInt("Year");
                        int newCount       = rs.getInt("NewCustomerCount");
                        int prevCount      = rs.getInt("PreviousYearCount");
                        int growth         = rs.getInt("Growth");
                        BigDecimal rate    = rs.getBigDecimal("GrowthRate");
                        String rateStr     = (rate == null ? "N/A" : rate.toString());

                        System.out.printf(
                            "%d\t%d\t%d\t%d\t%s%n",
                            year, newCount, prevCount, growth, rateStr
                        );
                    }
                }
            } else {
                System.out.println("No data returned by p_createCustomerGrowthReportByYear.");
            }

        } catch (SQLException e) {
            System.err.println("Failed to generate customer growth report by year: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
