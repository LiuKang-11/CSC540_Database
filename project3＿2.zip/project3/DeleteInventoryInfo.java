package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the deletion of inventory information.
 * It prompts the user for StoreID and ProductID, and deletes the corresponding record from the Inventory table.
 */
public class DeleteInventoryInfo {
    public static void deleteInventoryQuantity() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter StoreID: ");
        int storeID = scanner.nextInt();
        System.out.print("Enter ProductID: ");
        int productID = scanner.nextInt();
        scanner.nextLine();
        
        String sql = "DELETE FROM Inventory WHERE StoreID = ? AND ProductID = ?";

        
        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setInt(1, storeID);
            ps.setInt(2, productID);
            
            try (ResultSet rs = ps.executeQuery()) {
                System.out.println("Delete successfully on product " + productID + " in store " + storeID);
            }
        } catch (SQLException e) {
            System.err.println("Failed to retrieve inventory：" + e.getMessage());
            e.printStackTrace();
        }
    }
}