package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the retrieval of inventory information.
 * It prompts the user for StoreID and ProductID, and retrieves the corresponding inventory details from the database.
 */
public class GetInventoryInfo {
    public static void getInventoryInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter StoreID: ");
        int storeID = scanner.nextInt();
        System.out.print("Enter ProductID: ");
        int productID = scanner.nextInt();
        scanner.nextLine();
        
        String sql = "SELECT * FROM Inventory WHERE StoreID = ? AND ProductID = ?";
        
        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setInt(1, storeID);
            ps.setInt(2, productID);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    System.out.println("===== Inventory Information =====");
                    System.out.println("StoreID: " + rs.getInt("StoreID"));
                    System.out.println("ProductID: " + rs.getInt("ProductID"));
                    System.out.println("Quantity: " + rs.getInt("Quantity"));
                    System.out.println("DiscountInfo: " + rs.getInt("DiscountInfo"));
                    System.out.println("valid_from: " + rs.getString("valid_from"));
                    System.out.println("valid_to: " + rs.getString("valid_to"));
                    System.out.println("=====================");
                } else {
                    System.out.println("Can't find " + productID + "in" + storeID);
                }
            }
        } catch (SQLException e) {
            System.err.println("Failed to retrieve inventory：" + e.getMessage());
            e.printStackTrace();
        }
    }
}