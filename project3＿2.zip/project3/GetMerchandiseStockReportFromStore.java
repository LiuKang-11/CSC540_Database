package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the retrieval of merchandise stock report from a specific store.
 * It prompts the user for StoreID and retrieves the corresponding inventory details from the database.
 */
public class GetMerchandiseStockReportFromStore {
    public static void getMerchandiseStockReportFromStore() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter StoreID: ");
        int storeID = scanner.nextInt();
        scanner.nextLine();
        
        String sql = "SELECT * FROM Inventory WHERE StoreID = ?";
        
        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setInt(1, storeID);
            
            try (ResultSet rs = ps.executeQuery()) {
                boolean found = false;
                while (rs.next()) {
                    if (!found) {
                        System.out.println("===== Inventory Information =====");
                        found = true;
                    }
                    System.out.println("StoreID       : " + rs.getInt("StoreID"));
                    System.out.println("ProductID     : " + rs.getInt("ProductID"));
                    System.out.println("Quantity      : " + rs.getInt("Quantity"));
                    System.out.println("DiscountInfo  : " + rs.getInt("DiscountInfo"));
                    System.out.println("ValidFrom     : " + rs.getDate("valid_from"));
                    System.out.println("ValidTo       : " + rs.getDate("valid_to"));
                    System.out.println("-------------------------------");
                }
                if (!found) {
                    System.out.println("Can't find inventory for StoreID = " + storeID);
                } else {
                    System.out.println("===== End of Report =====");
                }
            }
        } catch (SQLException e) {
            System.err.println("Failed to retrieve inventory: " + e.getMessage());
            e.printStackTrace();
        }
    }
}