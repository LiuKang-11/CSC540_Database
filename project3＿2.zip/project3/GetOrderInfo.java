package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the retrieval of order information.
 * It prompts the user for StoreID, SupplierID, ProductID, and StaffID, and retrieves the corresponding order details from the database.
 */
public class GetOrderInfo {
    public static void getOrderInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter StoreID: ");
        int storeID = scanner.nextInt();
        System.out.print("Enter SupplierID: ");
        int supplierID = scanner.nextInt();
        System.out.print("Enter ProductID: ");
        int productID = scanner.nextInt();
        System.out.print("Enter Warehouse Checker ID: ");
        int staffID = scanner.nextInt();
        scanner.nextLine();
        
        String sql = "SELECT * FROM Orders WHERE StoreID = ? AND SupplierID = ? AND ProductID = ? AND StaffID = ?;";
        
        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setInt(1, storeID);
            ps.setInt(2, supplierID);
            ps.setInt(3, productID);
            ps.setInt(4, staffID);

            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    System.out.println("===== Order Information =====");
                    System.out.println("StoreID: " + rs.getInt("StoreID"));
                    System.out.println("SupplierID: " + rs.getInt("SupplierID"));
                    System.out.println("ProductID: " + rs.getInt("ProductID"));
                    System.out.println("StaffID(Warehouse Checker): " + rs.getInt("StaffID"));
                    System.out.println("Date: " + rs.getString("Date"));
                    System.out.println("Quantity: " + rs.getInt("Quantity"));
                    System.out.println("BuyPrice: " + rs.getInt("BuyPrice"));
                    System.out.println("OrderNumber: " + rs.getInt("OrderNumber"));
                    System.out.println("=====================");
                } else {
                    System.out.println("Can't find Order with StoreID = " + storeID + ", SupplierID = " + supplierID + 
                                                    ", ProductID = " + productID + ", StaffID = " + staffID );
                }
            }
        } catch (SQLException e) {
            System.err.println("Failed to retrieve Orders" + e.getMessage());
            e.printStackTrace();
        }
    }
}