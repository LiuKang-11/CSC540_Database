package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the retrieval of transfer information.
 * It prompts the user for Store IDs and Product ID, and retrieves the corresponding transfer details from the database.
 */
public class GetTransferInfo {

    /**
     * search
     */
    public static void getTransferInfo(Scanner scanner) {
        System.out.print("Enter StoreID1 (From): ");
        int storeID1 = Integer.parseInt(scanner.nextLine().trim());
        System.out.print("Enter StoreID2 (To): ");
        int storeID2 = Integer.parseInt(scanner.nextLine().trim());
        System.out.print("Enter ProductID: ");
        int productID = Integer.parseInt(scanner.nextLine().trim());

        String sql = 
            "SELECT * " +
            "FROM Transfer " +
            "WHERE Store1ID = ? " +
            "  AND Store2ID = ? " +
            "  AND Product1ID = ? " +
            "  AND Product2ID = ?";

        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, storeID1);
            ps.setInt(2, storeID2);
            ps.setInt(3, productID);
            ps.setInt(4, productID);

            try (ResultSet rs = ps.executeQuery()) {
                boolean found = false;
                while (rs.next()) {
                    if (!found) {
                        System.out.println("===== Transfer Information =====");
                    }
                    found = true;
                    System.out.println("Store1ID           : " + rs.getInt("Store1ID"));
                    System.out.println("Store2ID           : " + rs.getInt("Store2ID"));
                    System.out.println("Product1ID         : " + rs.getInt("Product1ID"));
                    System.out.println("Product2ID         : " + rs.getInt("Product2ID"));
                    System.out.println("Date               : " + rs.getString("Date"));
                    System.out.println("StaffID (Checker)  : " + rs.getInt("StaffID"));
                    System.out.println("Quantity           : " + rs.getInt("Quantity"));
                    System.out.println("TransferNumber     : " + rs.getInt("TransferNumber"));
                    System.out.println("---------------------------------");
                }
                if (!found) {
                    System.out.printf(
                        "Can't find Transfer info with Store1ID=%d, Store2ID=%d, ProductID=%d%n",
                        storeID1, storeID2, productID
                    );
                }
            }

        } catch (SQLException e) {
            System.err.println("Failed to retrieve Transfer: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
