package project3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This is the main class for the project.
 * It provides a menu-driven interface for various operations related to club members, stock, profit, staff, store, merchandise, and suppliers.
 * The program connects to a MariaDB database and executes various procedures based on user input.
 */

public class Main {
    // parameter
    private static final String DB_URL = "jdbc:mariadb://classdb2.csc.ncsu.edu:3306/xpi";
    private static final String DB_USER = "xpi";
    private static final String DB_PASSWORD = "200596200";
    
    private static Connection connection = null;
    public static final Scanner scanner = new Scanner(System.in);
    
    // get connection
    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        }
        return connection;
    }
    
    public static void main(String[] args) {
        // check connection
        try {
            getConnection();
        } catch (SQLException e) {
            System.err.println("Can't connect DB: " + e.getMessage());
            return;
        }
        
        try {
            while (true) {
                System.out.println("Choose operations：");
                
                System.out.println("=============Club Member=============");
                System.out.println("1. Create ClubMember Info");
                System.out.println("2. Create Cancel Info");
                System.out.println("3. Create Club Member's Reward Check");
                System.out.println("4. Create Customer Growth Report ByMonth");
                System.out.println("5. Create Customer Growth Report ByYear");
                System.out.println("6. Create Customer Activity Report");
                System.out.println("7. Customer Info");
                System.out.println("8. Sign Up Info");
                System.out.println("================Stock================");
                System.out.println("9. Create Orders");
                System.out.println("10. Create Transaction");
                System.out.println("11. Create Transfer");
                System.out.println("12. Return Product");
                System.out.println("13. Create Supplier Bill");
                System.out.println("14. Update Inventory Discount");
                System.out.println("15. Delete Inventory");
                System.out.println("16. Inventory Info");
                System.out.println("17. Order Info");
                System.out.println("18. Return Info");
                System.out.println("19. Trasfer Info");
                System.out.println("20. Update Inventory");
                System.out.println("21. Merchandise Info from Store");
                System.out.println("22. Merchandise Info from Product");
                System.out.println("================Profit================");
                System.out.println("23. Generate Sales Report");
                System.out.println("24. Generate Sales Growth Report");
                System.out.println("25. Generate Store Gross Profit Report");
                System.out.println("26. Generate Store Gross Profit Growth Report");
                System.out.println("================Staff================");
                System.out.println("27. Staff Info");
                System.out.println("28. Staff Info Creater");
                
                System.out.println("29. Staff Info Delete");
                System.out.println("30. Staff Info Update");
                System.out.println("================Store================");
                System.out.println("31. Store Info");
                System.out.println("32. Store Info Creater");

                System.out.println("33. Store Info Deleter");
                System.out.println("34. Store Info Update");
                System.out.println("=============Merchandise=============");
                System.out.println("35. Merch Info");
                System.out.println("36. Merch Info Creater");
                System.out.println("37. Merch Info Deleter");
                System.out.println("38. Merch Info Update");
                System.out.println("===============Supplier==============");
                System.out.println("39. Supplier Info");
                System.out.println("40. Supplier Info Creater");

                System.out.println("41. Supplier Info Deleter");
                System.out.println("42. Supplier Info Update");


            
                System.out.println("0. Exit Program");
                System.out.print("Select options (or use 'exit'): ");
                
                String input = scanner.nextLine().trim();
                if (input.equalsIgnoreCase("exit")) {
                    System.out.println("Exit Program。");
                    break;
                }
                
                int choice;
                try {
                    choice = Integer.parseInt(input);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid Input！");
                    continue;
                }
                
                switch (choice) {
                    case 1:
                        ClubMemberProcedure.createClubMember();
                        break;
                    case 2:
                        CancelProcedure.cancelMember(scanner);
                        break;
                    case 3:
                        RewardCheckProcedure.generateRewardCheck();
                        break;
                    case 4:
                    	CreateCustomerGrowthReportByMonthProcedure.createCustomerGrowthReportByMonth();
                    	break;
                    case 5:
                    	CreateCustomerGrowthReportByYearProcedure.createCustomerGrowthReportByYear();
                    	break;
                    case 6:
                    	CreateCustomerActivityReportProcedure.createCustomerActivityReport(scanner);
                    	break;
                    case 7:
                        ClubMemberInfo.getClubMember();
                        break;
                    case 8:
                    	SignUpInfo.getSignUpInfo();
                    	break;	
                    	
                    case 9:
                        OrderProcedure.createOrder(scanner);
                        break;
                    case 10:
                        TransactionProcedure.createTransaction(scanner);
                        break;
                    case 11:
                        TransferProcedure.createTransfer(scanner);
                        break;
                    case 12:
                        ReturnProductProcedure.returnProduct(scanner);
                        break;
                    case 13:
                    	SupplierBillProcedure.generateSupplierBill();
                    	break;
                    case 14:
                    	UpdateInventoryDiscountProcedure.updateInventoryDiscount();
                    	break;
                    case 15:
                    	DeleteInventoryInfo.deleteInventoryQuantity();
                    	break;
                    case 16:
                    	GetInventoryInfo.getInventoryInfo();
                    	break;
                    case 17: 
                    	GetOrderInfo.getOrderInfo();
                    	break;
                    case 18:
                    	GetReturnInfo.getReturnInfo();
                    	break;
                    case 19:
                    	GetTransferInfo.getTransferInfo(scanner);
                    	break;
                    case 20:
                    	UpdateInventoryInfo.updateInventoryQuantity(scanner);
                    	break;
                    case 21:
                    	GetMerchandiseStockReportFromStore.getMerchandiseStockReportFromStore();
                    	break;
                    case 22:
                    	GetMerchandiseStockReportFromProduct.getMerchandiseStockReportFromProduct();
                    	break;
                    	
                    case 23:
                    	SalesReportProcedure.generateSalesReport();
                    	break;
                    case 24:
                    	SalesGrowthReportProcedure.generateSalesGrowthReport();
                    	break;
                    case 25:
                        StoreGrossProfitReportProcedure.generateStoreGrossProfitReport();
                        break;
                    case 26:
                        StoreGrossProfitGrowthReportProcedure.generateStoreGrossProfitGrowthReport();
                        break;
                    case 27:
                    	StaffInfo.getStaffInfo(scanner);
                    	break;
                    case 28:
                    	createStaffInfo.createStaff(scanner);
                    	break;
                    	
                    case 29:
                    	StaffInfoDeleter.deleteStaffInfo();
                    	break;
                    case 30:
                    	UpdateStaffInfo.updateStaffInfo();
                    	break;
                    case 31:
                    	StoreInfo.getStoreInfo(scanner);
                    	break;
                    case 32:
                    	createStore.createStore(scanner);
                    	break;
                    	
                    case 33:
                    	StoreInfoDeleter.deleteStoreInfo();
                    	break;
                    case 34:
                    	UpdateStoreInfo.updateStoreInfo();
                    	break;
                    case 35:
                    	getMechInfo.getMerchInfo(scanner);
                    	break;
                    case 36:
                    	createMerchInfo.createMerchInfo(scanner);
                    	break;
                    case 37:
                    	deleteMerchInfo.deleteMerchInfo();
                    	break;
                    case 38:
                    	updateMerchInfo.updateMerchInfo();
                    	break;
                    case 39:
                    	getSupplierInfo.getSupplierInfo();
                    	break;
                    case 40:
                    	createSupplier.createSupplier(scanner);
                    	break;
                    	
                    case 41:
                    	deleteSupplierInfo.deleteSupplierInfo();
                    	break;
                    case 42:
                    	updateSupplierInfo.updateSupplierInfo();
                    	break;

                    case 0:
                        System.out.println("exit。");
                        return;
                    default:
                        System.out.println("Invalid Input！");
                }
            }
        } finally {
            close();
        }
    }
    
    // connection close
    private static void close() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Close connection。");
            } catch (SQLException e) {
                System.err.println("error for close connection：" + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}
