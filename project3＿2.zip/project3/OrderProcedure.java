// OrderProcedure.java
package project3;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the creation of orders.
 * It prompts the user for necessary information and calls a stored procedure to process the order creation.
 */
public class OrderProcedure {

    /**
     * build transaction
     */
    public static void createOrder(Scanner scanner) {
        System.out.print("StoreID: ");
        int storeID = Integer.parseInt(scanner.nextLine().trim());

        System.out.print("SupplierID: ");
        int supplierID = Integer.parseInt(scanner.nextLine().trim());

        System.out.print("ProductID: ");
        int productID = Integer.parseInt(scanner.nextLine().trim());

        System.out.print("StaffID: ");
        int staffID = Integer.parseInt(scanner.nextLine().trim());

        System.out.print("Quantity: ");
        int quantity = Integer.parseInt(scanner.nextLine().trim());

        System.out.print("Price: ");
        double price = Double.parseDouble(scanner.nextLine().trim());

        String call = "{CALL p_createOrders(?, ?, ?, ?, ?, ?)}";
        try (Connection conn = Main.getConnection();
             CallableStatement cs = conn.prepareCall(call)) {

            cs.setInt(1, storeID);
            cs.setInt(2, supplierID);
            cs.setInt(3, productID);
            cs.setInt(4, staffID);
            cs.setInt(5, quantity);
            cs.setDouble(6, price);

            // return ResultSet
            boolean hasRs = cs.execute();
            if (hasRs) {
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        int orderNumber = rs.getInt("OrderNumber");
                        System.out.println("New Order created, OrderNumber = " + orderNumber);
                    }
                }
            }
            System.out.println("Create Order success！");
        } catch (SQLException e) {
            System.err.println("Create Order failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
