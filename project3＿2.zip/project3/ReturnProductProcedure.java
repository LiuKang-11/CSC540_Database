// ReturnProductProcedure.java
package project3;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the return of products.
 * It prompts the user for necessary information and calls a stored procedure to process the return.
 */
public class ReturnProductProcedure {
    
    public static void returnProduct(Scanner scanner) {
        try {
            System.out.print("StoreID: ");
            int storeID = Integer.parseInt(scanner.nextLine().trim());

            System.out.print("ProductID: ");
            int productID = Integer.parseInt(scanner.nextLine().trim());

            System.out.print("StaffID: ");
            int staffID = Integer.parseInt(scanner.nextLine().trim());

            System.out.print("Quantity: ");
            int quantity = Integer.parseInt(scanner.nextLine().trim());

            System.out.print("CustomerID: ");
            int customerID = Integer.parseInt(scanner.nextLine().trim());

            String call = "{CALL p_returnProduct(?, ?, ?, ?, ?)}";
            try (Connection conn = Main.getConnection();
                 CallableStatement cs = conn.prepareCall(call)) {

                cs.setInt(1, storeID);
                cs.setInt(2, productID);
                cs.setInt(3, staffID);
                cs.setInt(4, quantity);
                cs.setInt(5, customerID);

                boolean hasRs = cs.execute();
                if (hasRs) {
                    try (ResultSet rs = cs.getResultSet()) {
                        while (rs.next()) {
                            int returnNumber = rs.getInt("ReturnNumber");
                            System.out.println("Return ID: " + returnNumber);
                        }
                    }
                }
                System.out.println("Return success！");
            }
        } catch (NumberFormatException e) {
            System.err.println("Invalid Input!");
        } catch (SQLException e) {
            System.err.println("Return failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
