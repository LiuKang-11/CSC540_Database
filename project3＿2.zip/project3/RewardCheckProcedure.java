package project3;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.math.BigDecimal;
import java.util.Scanner;

/**
 * This class handles the generation of a reward check for platinum members.
 * It prompts the user for a year and calls a stored procedure to generate the reward check.
 */
public class RewardCheckProcedure {

    public static void generateRewardCheck() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter year (YYYY): ");
        int year;
        try {
            year = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid year format.");
            return;
        }

        String call = "{CALL p_createRewardCheck(?)}";
        try (Connection conn = Main.getConnection();
             CallableStatement cs = conn.prepareCall(call)) {

            // setInt 
            cs.setInt(1, year);

            // get result
            boolean hasRs = cs.execute();
            if (hasRs) {
                try (ResultSet rs = cs.getResultSet()) {
                    System.out.println("===== Reward Check for " + year + " =====");
                    boolean found = false;
                    while (rs.next()) {
                        found = true;
                        int customerID    = rs.getInt("customerID");
                        BigDecimal reward = rs.getBigDecimal("TotalReward");
                        System.out.printf("CustomerID: %d, TotalReward: %s%n",
                                          customerID, reward);
                    }
                    if (!found) {
                        System.out.println("No platinum members found for year " + year);
                    }
                    System.out.println("====================================");
                }
            } else {
                System.out.println("No data returned by p_createRewardCheck.");
            }

        } catch (SQLException e) {
            System.err.println("Failed to generate reward check: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
