package project3;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.math.BigDecimal;
import java.util.Scanner;

/**
 * This class handles the generation of a sales growth report for a specific store.
 * It prompts the user for store ID and two months, and calls a stored procedure to generate the report.
 */
public class SalesGrowthReportProcedure {
    public static void generateSalesGrowthReport() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter storeID: ");
        int storeID;
        try {
            storeID = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid storeID format.");
            return;
        }
        System.out.print("Enter start month (YYYY-MM): ");
        String month1 = scanner.nextLine().trim();
        System.out.print("Enter end   month (YYYY-MM): ");
        String month2 = scanner.nextLine().trim();

        String call = "{CALL p_generateSalesGrowthReport(?, ?, ?)}";
        try (Connection conn = Main.getConnection();
             CallableStatement cs = conn.prepareCall(call)) {

            cs.setInt(1, storeID);
            cs.setString(2, month1);
            cs.setString(3, month2);

            // check result
            boolean hasRs = cs.execute();
            if (hasRs) {
                try (ResultSet rs = cs.getResultSet()) {
                    System.out.println("===== Sales Growth Report =====");
                    if (rs.next()) {
                        BigDecimal sales1 = rs.getBigDecimal("Sales_Month1");
                        BigDecimal sales2 = rs.getBigDecimal("Sales_Month2");
                        BigDecimal growth = rs.getBigDecimal("Growth_Rate");
                        System.out.printf("Sales in %s: %s%n", month1, sales1);
                        System.out.printf("Sales in %s: %s%n", month2, sales2);
                        System.out.printf("Growth Rate  : %s%%%n", growth);
                    } else {
                        System.out.println("No data returned for StoreID=" + storeID);
                    }
                    System.out.println("================================");
                }
            } else {
                System.out.println("No data returned by p_generateSalesGrowthReport.");
            }
        } catch (SQLException e) {
            System.err.println("Failed to generate sales growth report: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
