package project3;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.ResultSet;

/**
 * This class handles the generation of sales reports.
 * It prompts the user for necessary information and calls a stored procedure to generate the report.
 */
public class SalesReportProcedure {
	public static void generateSalesReport() {
	    Scanner scanner = new Scanner(System.in);
	    System.out.print("Enter storeID: ");
	    int storeID = Integer.parseInt(scanner.nextLine());
	    System.out.print("Enter year (YYYY, 0=all): ");
	    int year    = Integer.parseInt(scanner.nextLine());
	    System.out.print("Enter month (MM, 0=all): ");
	    int month   = Integer.parseInt(scanner.nextLine());
	    System.out.print("Enter day (DD, 0=all): ");
	    int day     = Integer.parseInt(scanner.nextLine());

	    String call = "{CALL p_generateSalesReport(?, ?, ?, ?)}";
	    try (Connection conn = Main.getConnection();
	         CallableStatement cs = conn.prepareCall(call)) {
	         
	        cs.setInt(1, storeID);
	        cs.setInt(2, year);
	        cs.setInt(3, month);
	        cs.setInt(4, day);

	        // get result
	        boolean hasRs = cs.execute();
	        if (hasRs) {
	            try (ResultSet rs = cs.getResultSet()) {
	                System.out.println("===== Sales Report =====");
	                while (rs.next()) {
	                    // p_generateSalesReport
	                    if (year == 0) {
	                        System.out.printf("Year: %d, TotalSales: %s%n",
	                            rs.getInt("SalesYear"),
	                            rs.getBigDecimal("TotalSales"));
	                    } else if (month == 0) {
	                        System.out.printf("Month: %d, TotalSales: %s%n",
	                            rs.getInt("SalesMonth"),
	                            rs.getBigDecimal("TotalSales"));
	                    } else if (day == 0) {
	                        System.out.printf("Day: %d, TotalSales: %s%n",
	                            rs.getInt("SalesDay"),
	                            rs.getBigDecimal("TotalSales"));
	                    } else {
	                        System.out.printf("Date: %d-%02d-%02d, TotalSales: %s%n",
	                            rs.getInt("SalesYear"),
	                            rs.getInt("SalesMonth"),
	                            rs.getInt("SalesDay"),
	                            rs.getBigDecimal("TotalSales"));
	                    }
	                }
	                System.out.println("=========================");
	            }
	        } else {
	            System.out.println("No data returned by report.");
	        }
	    } catch (SQLException e) {
	        System.err.println("Failed to generate sales report: " + e.getMessage());
	        e.printStackTrace();
	    }
	}

}
