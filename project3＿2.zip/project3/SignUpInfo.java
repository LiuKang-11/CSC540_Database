package project3;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


/**
 * This class handles the retrieval of sign-up information for a customer.
 * It prompts the user for a customer ID and retrieves the corresponding sign-up details from the database.
 */
public class SignUpInfo {


   // search
   public static void getSignUpInfo() {
       Scanner scanner = new Scanner(System.in);
       System.out.print("Enter Customer ID: ");
       int customerID = scanner.nextInt();
       scanner.nextLine();  // 
      
       // PreparedStatement 
       String sql = "SELECT *" +
                    "FROM SignUp WHERE CustomerID = ?";
      
       try (Connection conn = Main.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
           
           ps.setInt(1, customerID);
          
           try (ResultSet rs = ps.executeQuery()) {
               if (rs.next()) {
                   System.out.println("===== SignUp Info =====");
                   System.out.println("StaffID: " + rs.getInt("StaffID"));
                   System.out.println("CustomerID: " + rs.getInt("CustomerID"));
                   System.out.println("SignUpNumber: " + rs.getInt("SignUpNumber"));
                   System.out.println("Date: " + rs.getDate("Date"));
                   System.out.println("StoreID: " + rs.getInt("StoreID"));
                   
                   System.out.println("=====================");
               } else {
                   System.out.println("Can't find Customer ID: " + customerID);
               }
           }
       } catch (SQLException e) {
           System.err.println("Search failed：" + e.getMessage());
           e.printStackTrace();
       }
   }
}

