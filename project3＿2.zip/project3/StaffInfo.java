package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the retrieval of staff information.
 * It prompts the user for a staff ID and retrieves the corresponding staff details from the database.
 */
public class StaffInfo {

  
    public static void getStaffInfo(Scanner scanner) {
        System.out.print("Enter Staff ID: ");
        int staffID;
        try {
            staffID = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid Staff ID format.");
            return;
        }

        String sql = 
            "SELECT StaffID, StoreID, JobTitle, Name, Age, PhoneNumber, Email, HomeAddress, TimeOfEmployment " +
            "FROM Staff " +
            "WHERE StaffID = ?";

        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, staffID);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    System.out.println("===== Staff Info =====");
                    System.out.println("StaffID           : " + rs.getInt("StaffID"));
                    System.out.println("StoreID           : " + rs.getInt("StoreID"));
                    System.out.println("JobTitle          : " + rs.getString("JobTitle"));
                    System.out.println("Name              : " + rs.getString("Name"));
                    System.out.println("Age               : " + rs.getInt("Age"));
                    System.out.println("PhoneNumber       : " + rs.getString("PhoneNumber"));
                    System.out.println("Email             : " + rs.getString("Email"));
                    System.out.println("HomeAddress       : " + rs.getString("HomeAddress"));
                    System.out.println("TimeOfEmployment  : " + rs.getInt("TimeOfEmployment"));
                    System.out.println("======================");
                } else {
                    System.out.println("Can't find staff with ID = " + staffID);
                }
            }

        } catch (SQLException e) {
            System.err.println("Search Staff failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
