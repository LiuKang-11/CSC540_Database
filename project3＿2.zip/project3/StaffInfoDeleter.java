package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the deletion of staff information.
 * It prompts the user for a Staff ID and deletes the corresponding record from the Staff table.
 */
public class StaffInfoDeleter {

    // delete
    public static void deleteStaffInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Staff ID: ");
        int staffID = scanner.nextInt();
        scanner.nextLine();  // 
        
        System.out.println("Warn：The info of this Staff will be deleted and can't recovered！");
        System.out.print("Confirm to delete ID: " + staffID + "？(y/n): ");
        String confirm = scanner.nextLine();
        
        if (!confirm.equalsIgnoreCase("y")) {
            System.out.println("Operation cancel");
            return;
        }
        
        // 
        String sql = "DELETE FROM Staff " +
                     "WHERE StaffID = ?";
        
        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setInt(1, staffID);
            
            int rowsAffected = ps.executeUpdate();
            
            if (rowsAffected > 0) {
                System.out.println("Delete success, affec " + rowsAffected + " row");
            } else {
                System.out.println("Can't find ID: " + staffID);
            }
        } catch (SQLException e) {
            System.err.println("Delete failed：" + e.getMessage());
            e.printStackTrace();
        }
    }
}