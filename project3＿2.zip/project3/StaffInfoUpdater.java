package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the update of staff information.
 * It prompts the user for a Staff ID and a new phone number, and updates the corresponding record in the Staff table.
 */
public class StaffInfoUpdater {

    // update
    public static void updateStaffInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Staff ID: ");
        int staffID = scanner.nextInt();
        scanner.nextLine();  // 
        
        System.out.print("Enter New phone number: ");
        String phoneNumber = scanner.nextLine();
        
        // PreparedStatement 
        String sql = "UPDATE Staff " +
                     "SET PhoneNumber = ? " +
                     "WHERE StaffID = ?";
        
        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setString(1, phoneNumber);
            ps.setInt(2, staffID);
            
            int rowsAffected = ps.executeUpdate();
            
            if (rowsAffected > 0) {
                System.out.println("Update success, affect " + rowsAffected + "row");
            } else {
                System.out.println("Can't find ID: " + staffID);
            }
        } catch (SQLException e) {
            System.err.println("Update failed：" + e.getMessage());
            e.printStackTrace();
        }
    }
}