package project3;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.Scanner;

/**
 * This class handles the generation of a store gross profit growth report.
 * It prompts the user for store ID, period type, number of periods, and end date,
 * and calls a stored procedure to generate the report.
 */
public class StoreGrossProfitGrowthReportProcedure {

    public static void generateStoreGrossProfitGrowthReport() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter StoreID: ");
        int storeID;
        try {
            storeID = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid StoreID format.");
            return;
        }

        System.out.print("Enter Period Type (monthly/quarterly/yearly): ");
        String periodType = scanner.nextLine().trim();

        System.out.print("Enter number of periods: ");
        int numPeriods;
        try {
            numPeriods = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid number format for periods.");
            return;
        }

        System.out.print("Enter end date (YYYY-MM-DD): ");
        String endInput = scanner.nextLine().trim();

        String call = "{CALL p_generateStoreGrossProfitGrowthReport(?, ?, ?, ?)}";
        try (Connection conn = Main.getConnection();
             CallableStatement cs = conn.prepareCall(call)) {

            cs.setInt(1, storeID);
            cs.setString(2, periodType);
            cs.setInt(3, numPeriods);
            cs.setDate(4, Date.valueOf(endInput));

         // 
            boolean hasRs = cs.execute();
            if (hasRs) {
                try (ResultSet rs = cs.getResultSet()) {
                    System.out.println("===== Gross Profit Growth Report =====");
                    System.out.printf("%-12s %-15s %-20s %-15s%n",
                        "Period", "GrossProfit", "PreviousGrossProfit", "GrowthPercentage");
                    while (rs.next()) {
                        String period = rs.getString("Period");
                        BigDecimal gp  = rs.getBigDecimal("GrossProfit");
                        BigDecimal prev = rs.getBigDecimal("PreviousGrossProfit");
                        BigDecimal pct  = rs.getBigDecimal("GrowthPercentage");

                        //  NULL 
                        String prevStr = (prev == null ? "N/A" : prev.toString());
                        String pctStr  = (pct  == null ? "N/A" : pct.toString());

                        System.out.printf("%-12s %-15.2f %-20s %-15s%%%n",
                            period,
                            gp != null ? gp.doubleValue() : 0.0,
                            prevStr,
                            pctStr
                        );
                    }
                    System.out.println("======================================");
                }
            } else {
                System.out.println("No data returned by p_generateStoreGrossProfitGrowthReport.");
            }

        } catch (SQLException e) {
            System.err.println("Failed to generate gross profit growth report: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
