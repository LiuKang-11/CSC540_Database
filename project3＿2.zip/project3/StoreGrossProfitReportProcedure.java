package project3;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.Scanner;

/**
 * This class handles the generation of a store gross profit report.
 * It prompts the user for a store ID, date range, and report detail level,
 * then calls a stored procedure to generate the report.
 */
public class StoreGrossProfitReportProcedure {

    public static void generateStoreGrossProfitReport() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter storeID: ");
        int storeID;
        try {
            storeID = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid storeID format.");
            return;
        }

        System.out.print("Enter start date (YYYY-MM-DD): ");
        String startInput = scanner.nextLine().trim();
        System.out.print("Enter   end date (YYYY-MM-DD): ");
        String endInput   = scanner.nextLine().trim();
        System.out.print("Enter report detail level (product/overall): ");
        String detail     = scanner.nextLine().trim();

        String call = "{CALL p_generateStoreGrossProfitReport(?, ?, ?, ?)}";
        try (Connection conn = Main.getConnection();
             CallableStatement cs = conn.prepareCall(call)) {

            cs.setInt(1, storeID);
            cs.setDate(2, Date.valueOf(startInput));
            cs.setDate(3, Date.valueOf(endInput));
            cs.setString(4, detail);

            boolean hasRs = cs.execute();
            if (hasRs) {
                try (ResultSet rs = cs.getResultSet()) {
                    System.out.println("===== Gross Profit Report =====");
                    if ("product".equalsIgnoreCase(detail)) {
                        System.out.printf("%-10s %-20s %-10s %-15s %-15s %-15s %-15s%n",
                            "ProductID","ProductName","QtySold","Revenue","Cost","GrossProfit","Margin(%)");
                        while (rs.next()) {
                            int pid    = rs.getInt("ProductID");
                            String name= rs.getString("ProductName");
                            int qty    = rs.getInt("TotalQuantitySold");
                            BigDecimal rev  = rs.getBigDecimal("TotalRevenue");
                            BigDecimal cost = rs.getBigDecimal("TotalCost");
                            BigDecimal gp   = rs.getBigDecimal("GrossProfit");
                            BigDecimal m    = rs.getBigDecimal("GrossProfitMargin");
                            System.out.printf("%-10d %-20s %-10d %-15s %-15s %-15s %-15s%n",
                                pid,name,qty,rev,cost,gp,m);
                        }
                    } else {
                        System.out.printf("%-10s %-20s %-15s %-15s %-15s %-15s %-10s %-10s%n",
                            "StoreID","StoreAddress","Revenue","Cost","GrossProfit","Margin(%)","#Products","#Customers");
                        while (rs.next()) {
                            int sid    = rs.getInt("StoreID");
                            String addr= rs.getString("StoreAddress");
                            BigDecimal rev  = rs.getBigDecimal("TotalRevenue");
                            BigDecimal cost = rs.getBigDecimal("TotalCost");
                            BigDecimal gp   = rs.getBigDecimal("GrossProfit");
                            BigDecimal m    = rs.getBigDecimal("GrossProfitMargin");
                            int np   = rs.getInt("NumberOfProductsSold");
                            int nc   = rs.getInt("NumberOfCustomers");
                            System.out.printf("%-10d %-20s %-15s %-15s %-15s %-15s %-10d %-10d%n",
                                sid,addr,rev,cost,gp,m,np,nc);
                        }
                    }
                    System.out.println("================================");
                }
            } else {
                System.out.println("No data returned by p_generateStoreGrossProfitReport.");
            }
        } catch (SQLException e) {
            System.err.println("Failed to generate gross profit report: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
