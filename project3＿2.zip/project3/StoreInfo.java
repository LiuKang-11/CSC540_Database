package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the retrieval of store information.
 * It prompts the user for a store ID and retrieves the corresponding store details from the database.
 */
public class StoreInfo {

  
    public static void getStoreInfo(Scanner scanner) {
        System.out.print("Enter Store ID: ");
        int storeID;
        try {
            storeID = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid Store ID format.");
            return;
        }

        String sql =
            "SELECT StoreID, ManagerID, StoreAddress, PhoneNumber " +
            "FROM Store " +
            "WHERE StoreID = ?";

        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, storeID);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    System.out.println("===== Store Info =====");
                    System.out.printf("StoreID      : %d%n", rs.getInt("StoreID"));
                    System.out.printf("ManagerID    : %s%n",
                        rs.getObject("ManagerID") != null
                            ? rs.getInt("ManagerID")
                            : "NULL");
                    System.out.printf("StoreAddress : %s%n", rs.getString("StoreAddress"));
                    System.out.printf("PhoneNumber  : %s%n", rs.getString("PhoneNumber"));
                    System.out.println("======================");
                } else {
                    System.out.println("Can't find StoreID = " + storeID);
                }
            }

        } catch (SQLException e) {
            System.err.println("Search failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
