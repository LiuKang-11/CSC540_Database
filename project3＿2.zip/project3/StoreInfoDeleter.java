package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the deletion of store information.
 * It prompts the user for a Store ID and deletes the corresponding record from the Store table.
 */
public class StoreInfoDeleter {

    // delete
    public static void deleteStoreInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Store ID: ");
        int storeID = scanner.nextInt();
        scanner.nextLine();  // 
        
        System.out.println("Warn, the store will be deleted and can't recovered");
        System.out.print("Confirm delete ID:" + storeID + "？(y/n): ");
        String confirm = scanner.nextLine();
        
        if (!confirm.equalsIgnoreCase("y")) {
            System.out.println("Operation Cancel");
            return;
        }
        
        // 
        String sql = "DELETE FROM Store " +
                     "WHERE StoreID = ?";
        
        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setInt(1, storeID);
            
            int rowsAffected = ps.executeUpdate();
            
            if (rowsAffected > 0) {
                System.out.println("Delete success, affect " + rowsAffected + "row");
            } else {
                System.out.println("Can't find ID: " + storeID);
            }
        } catch (SQLException e) {
            System.err.println("Delete Store failed：" + e.getMessage());
            e.printStackTrace();
        }
    }
}