package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the update of store information.
 * It prompts the user for a Store ID and a new phone number, and updates the corresponding record in the Store table.
 */
public class StoreInfoUpdater {

    // update
    public static void updateStoreInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Store ID: ");
        int storeID = scanner.nextInt();
        scanner.nextLine();  // 
        
        System.out.print("Enter new phone number: ");
        String phoneNumber = scanner.nextLine();
        
        // PreparedStatement 
        String sql = "UPDATE Store " +
                     "SET PhoneNumber = ? " +
                     "WHERE StoreID = ?";
        
        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setString(1, phoneNumber);
            ps.setInt(2, storeID);
            
            int rowsAffected = ps.executeUpdate();
            
            if (rowsAffected > 0) {
                System.out.println("Update Store success! affect " + rowsAffected + "row");
            } else {
                System.out.println("Can't find ID: " + storeID);
            }
        } catch (SQLException e) {
            System.err.println("Update Store failed：" + e.getMessage());
            e.printStackTrace();
        }
    }
}