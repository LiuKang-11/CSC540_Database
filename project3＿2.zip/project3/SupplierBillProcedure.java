package project3;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.math.BigDecimal;
import java.util.Scanner;

/**
 * This class handles the generation of supplier bills.
 * It prompts the user for a year and month, and calls a stored procedure to generate the bill.
 */
public class SupplierBillProcedure {

    public static void generateSupplierBill() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter year (YYYY): ");
        int year;
        try {
            year = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid year format.");
            return;
        }
        System.out.print("Enter month (MM): ");
        int month;
        try {
            month = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid month format.");
            return;
        }

        String call = "{CALL p_createSupplierBill(?, ?)}";
        try (Connection conn = Main.getConnection();
             CallableStatement cs = conn.prepareCall(call)) {

            cs.setInt(1, year);
            cs.setInt(2, month);

            // 执行并获取结果集
            boolean hasRs = cs.execute();
            if (hasRs) {
                try (ResultSet rs = cs.getResultSet()) {
                    System.out.printf("===== Supplier Bill for %d-%02d =====%n", year, month);
                    boolean found = false;
                    while (rs.next()) {
                        found = true;
                        int supplierID    = rs.getInt("SupplierID");
                        BigDecimal totalBill = rs.getBigDecimal("TotalBill");
                        System.out.printf("SupplierID: %d, TotalBill: %s%n",
                                          supplierID, totalBill);
                    }
                    if (!found) {
                        System.out.println("No supplier bills found for " + year + "-" + String.format("%02d", month));
                    }
                    System.out.println("======================================");
                }
            } else {
                System.out.println("No data returned by p_createSupplierBill.");
            }
        } catch (SQLException e) {
            System.err.println("Failed to generate supplier bill: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
