package project3;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the creation of a transaction.
 * It prompts the user for necessary information and calls a stored procedure to process the transaction.
 */
public class TransactionProcedure {
    public static void createTransaction(Scanner scanner) {
        System.out.print("Enter StoreID: ");
        int storeID = Integer.parseInt(scanner.nextLine().trim());

        System.out.print("Enter CustomerID: ");
        int customerID = Integer.parseInt(scanner.nextLine().trim());

        System.out.print("Enter CashierID: ");
        int cashierID = Integer.parseInt(scanner.nextLine().trim());

        System.out.print("Enter ProductID: ");
        int productID = Integer.parseInt(scanner.nextLine().trim());

        System.out.print("Enter Quantity: ");
        int quantity = Integer.parseInt(scanner.nextLine().trim());

        String call = "{CALL p_createTransaction(?, ?, ?, ?, ?)}";
        try (Connection conn = Main.getConnection();
             CallableStatement cs = conn.prepareCall(call)) {

            cs.setInt(1, storeID);
            cs.setInt(2, customerID);
            cs.setInt(3, cashierID);
            cs.setInt(4, productID);
            cs.setInt(5, quantity);

            cs.execute();
            System.out.println("Create Transaction success！");
        } catch (SQLException e) {
            System.err.println("Create Transaction failed：" + e.getMessage());
            e.printStackTrace();
        }
    }
}
