package project3;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class TransferProcedure {

    /**
     */
    public static void createTransfer(Scanner scanner) {
        try {
            System.out.print("Store1ID: ");
            int store1ID = Integer.parseInt(scanner.nextLine().trim());

            System.out.print("Store2ID: ");
            int store2ID = Integer.parseInt(scanner.nextLine().trim());

            System.out.print("Product1ID: ");
            int product1ID = Integer.parseInt(scanner.nextLine().trim());

            System.out.print("Product2ID: ");
            int product2ID = Integer.parseInt(scanner.nextLine().trim());

            System.out.print("StaffID: ");
            int staffID = Integer.parseInt(scanner.nextLine().trim());

            System.out.print("Quantity: ");
            int quantity = Integer.parseInt(scanner.nextLine().trim());

            String call = "{CALL p_createTransfer(?, ?, ?, ?, ?, ?)}";
            try (Connection conn = Main.getConnection();
                 CallableStatement cs = conn.prepareCall(call)) {

                cs.setInt(1, store1ID);
                cs.setInt(2, store2ID);
                cs.setInt(3, product1ID);
                cs.setInt(4, product2ID);
                cs.setInt(5, staffID);
                cs.setInt(6, quantity);

                boolean hasRs = cs.execute();
                if (hasRs) {
                    try (ResultSet rs = cs.getResultSet()) {
                        if (rs.next()) {
                            int transferNumber = rs.getInt("TransferNumber");
                            System.out.println("New TransferNumber: " + transferNumber);
                        }
                    }
                }
                System.out.println("Transfer created successfully!");
            }
        } catch (SQLException e) {
            if ("45000".equals(e.getSQLState())
                && e.getMessage().contains("Insufficient stock")) {
                System.err.println("Error: Not enough number。");
            } else {
                System.err.println("Transfer failed: " + e.getMessage());
                e.printStackTrace();
            }
        } catch (NumberFormatException e) {
            System.err.println("Invalid Input!。");
        }
    }
}