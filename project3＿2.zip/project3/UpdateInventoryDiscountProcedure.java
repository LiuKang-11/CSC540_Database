package project3;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

/**
 * This class handles the updating of inventory discount information.
 * It prompts the user for necessary information and calls a stored procedure to process the update.
 */
public class UpdateInventoryDiscountProcedure {

    public static void updateInventoryDiscount() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter storeID: ");
        int storeID;
        try {
            storeID = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid storeID format.");
            return;
        }

        System.out.print("Enter productID: ");
        int productID;
        try {
            productID = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid productID format.");
            return;
        }

        System.out.print("Enter discount (0-100): ");
        double discount;
        try {
            discount = Double.parseDouble(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid discount format.");
            return;
        }

        System.out.print("Enter discount valid from date (YYYY-MM-DD or NULL): ");
        String fromInput = scanner.nextLine().trim();
        System.out.print("Enter discount valid to   date (YYYY-MM-DD or NULL): ");
        String toInput   = scanner.nextLine().trim();

        String call = "{CALL p_updateInventoryDiscount(?, ?, ?, ?, ?)}";
        try (Connection conn = Main.getConnection();
             CallableStatement cs = conn.prepareCall(call)) {

            cs.setInt(1, storeID);
            cs.setInt(2, productID);
            cs.setDouble(3, discount);

            // valid_from
            if (fromInput.equalsIgnoreCase("NULL") || fromInput.isEmpty()) {
                cs.setNull(4, Types.DATE);
            } else {
                cs.setDate(4, Date.valueOf(fromInput));
            }

            // valid_to
            if (toInput.equalsIgnoreCase("NULL") || toInput.isEmpty()) {
                cs.setNull(5, Types.DATE);
            } else {
                cs.setDate(5, Date.valueOf(toInput));
            }

            // 
            boolean hasRs = cs.execute();
            if (hasRs) {
                try (var rs = cs.getResultSet()) {
                    System.out.println("===== Updated Inventory Row =====");
                    // p_updateInventoryDiscount 
                    while (rs.next()) {
                        System.out.printf(
                            "StoreID=%d, ProductID=%d, Quantity=%d, DiscountInfo=%.2f, ValidFrom=%s, ValidTo=%s%n",
                            rs.getInt("StoreID"),
                            rs.getInt("ProductID"),
                            rs.getInt("Quantity"),
                            rs.getDouble("DiscountInfo"),
                            rs.getDate("valid_from"),
                            rs.getDate("valid_to")
                        );
                    }
                }
            } else {
                System.out.println("No data returned by p_updateInventoryDiscount.");
            }

        } catch (SQLException e) {
            System.err.println("Failed to update inventory discount: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
