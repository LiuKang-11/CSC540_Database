package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the update of inventory information.
 * It prompts the user for StoreID, ProductID, and new quantity, and updates the corresponding record in the Inventory table.
 */
public class UpdateInventoryInfo {

 
    public static void updateInventoryQuantity(Scanner scanner) {
        System.out.print("Enter StoreID: ");
        int storeID = Integer.parseInt(scanner.nextLine().trim());

        System.out.print("Enter ProductID: ");
        int productID = Integer.parseInt(scanner.nextLine().trim());

        System.out.print("Enter NEW Quantity that want to update: ");
        int quantity = Integer.parseInt(scanner.nextLine().trim());

        String updateSql = 
            "UPDATE Inventory " +
            "SET Quantity = ? " +
            "WHERE StoreID = ? AND ProductID = ?";

        try (Connection conn = Main.getConnection();
             PreparedStatement psUpdate = conn.prepareStatement(updateSql)) {

            psUpdate.setInt(1, quantity);
            psUpdate.setInt(2, storeID);
            psUpdate.setInt(3, productID);

            // update
            int affected = psUpdate.executeUpdate();
            if (affected == 0) {
                System.out.printf(
                  "Can't find ProductID=%d in StoreID=%d, no rows updated.%n",
                  productID, storeID);
                return;
            }
            System.out.printf("Update successful, %d row(s) affected.%n", affected);

            // 
            String selectSql = 
                "SELECT StoreID, ProductID, Quantity, DiscountInfo, valid_from, valid_to " +
                "FROM Inventory " +
                "WHERE StoreID = ? AND ProductID = ?";

            try (PreparedStatement psSelect = conn.prepareStatement(selectSql)) {
                psSelect.setInt(1, storeID);
                psSelect.setInt(2, productID);
                try (ResultSet rs = psSelect.executeQuery()) {
                    if (rs.next()) {
                        System.out.println("===== Inventory Information =====");
                        System.out.println("StoreID      : " + rs.getInt("StoreID"));
                        System.out.println("ProductID    : " + rs.getInt("ProductID"));
                        System.out.println("Quantity     : " + rs.getInt("Quantity"));
                        System.out.println("DiscountInfo : " + rs.getInt("DiscountInfo"));
                        System.out.println("valid_from   : " + rs.getString("valid_from"));
                        System.out.println("valid_to     : " + rs.getString("valid_to"));
                        System.out.println("=================================");
                    }
                }
            }

        } catch (SQLException e) {
            System.err.println("Failed to update inventory: " + e.getMessage());
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.err.println("Invalid input。");
        }
    }
}
