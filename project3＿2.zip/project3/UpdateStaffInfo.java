package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.Types;  

/**
 * This class handles the update of staff information.
 * It prompts the user for a StaffID and retrieves the corresponding staff's details from the database.
 * The user can then update any of the staff's information.
 */
public class UpdateStaffInfo {

 
    public static void updateStaffInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter StaffID: ");
        int staffID;
        try {
            staffID = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid StaffID format. Must be a number.");
            return;
        }

        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                 "SELECT StoreID, JobTitle, Name, Age, PhoneNumber, Email, HomeAddress, TimeOfEmployment " +
                 "FROM Staff WHERE StaffID = ?")) {

            // 
            ps.setInt(1, staffID);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    System.err.println("Staff with ID " + staffID + " not found.");
                    return;
                }

                int currentStoreID         = rs.getInt("StoreID");
                String currentJobTitle     = rs.getString("JobTitle");
                String currentName         = rs.getString("Name");
                int currentAge             = rs.getInt("Age");
                String currentPhoneNumber  = rs.getString("PhoneNumber");
                String currentEmail        = rs.getString("Email");
                String currentHomeAddress  = rs.getString("HomeAddress");
                int currentTimeOfEmployment = rs.getInt("TimeOfEmployment");

                // print
                System.out.println("\nCurrent Staff Information:");
                System.out.println("1. StoreID           : " + currentStoreID);
                System.out.println("2. JobTitle          : " + currentJobTitle);
                System.out.println("3. Name              : " + currentName);
                System.out.println("4. Age               : " + currentAge);
                System.out.println("5. PhoneNumber       : " + currentPhoneNumber);
                System.out.println("6. Email             : " + currentEmail);
                System.out.println("7. HomeAddress       : " + currentHomeAddress);
                System.out.println("8. TimeOfEmployment  : " + currentTimeOfEmployment);

                System.out.println("\nEnter new values (press Enter to keep current, type 'NULL' to set null):");

                // read
                System.out.print("Enter New StoreID [" + currentStoreID + "]: ");
                String storeIDInput = scanner.nextLine().trim();
                Integer newStoreID = storeIDInput.isEmpty() 
                    ? currentStoreID 
                    : storeIDInput.equalsIgnoreCase("NULL") 
                        ? null 
                        : Integer.parseInt(storeIDInput);

                System.out.print("Enter New JobTitle [" + currentJobTitle + "]: ");
                String newJobTitle = scanner.nextLine().trim();
                if (newJobTitle.isEmpty()) {
                    newJobTitle = currentJobTitle;
                } else if (newJobTitle.equalsIgnoreCase("NULL")) {
                    System.err.println("JobTitle is NOT NULL, keeping current value.");
                    newJobTitle = currentJobTitle;
                }

                System.out.print("Enter New Name [" + currentName + "]: ");
                String newName = scanner.nextLine().trim();
                if (newName.isEmpty()) {
                    newName = currentName;
                } else if (newName.equalsIgnoreCase("NULL")) {
                    System.err.println("Name is NOT NULL, keeping current value.");
                    newName = currentName;
                }

                System.out.print("Enter New Age [" + currentAge + "]: ");
                String ageInput = scanner.nextLine().trim();
                Integer newAge = ageInput.isEmpty() 
                    ? currentAge 
                    : ageInput.equalsIgnoreCase("NULL") 
                        ? null 
                        : Integer.parseInt(ageInput);

                System.out.print("Enter New PhoneNumber [" + currentPhoneNumber + "]: ");
                String newPhoneNumber = scanner.nextLine().trim();
                if (newPhoneNumber.isEmpty()) {
                    newPhoneNumber = currentPhoneNumber;
                } else if (newPhoneNumber.equalsIgnoreCase("NULL")) {
                    System.err.println("PhoneNumber is NOT NULL, keeping current value.");
                    newPhoneNumber = currentPhoneNumber;
                }

                System.out.print("Enter New Email [" + currentEmail + "]: ");
                String newEmail = scanner.nextLine().trim();
                if (newEmail.isEmpty()) {
                    newEmail = currentEmail;
                } else if (newEmail.equalsIgnoreCase("NULL")) {
                    System.err.println("Email is NOT NULL, keeping current value.");
                    newEmail = currentEmail;
                }

                System.out.print("Enter New HomeAddress [" + currentHomeAddress + "]: ");
                String newHomeAddress = scanner.nextLine().trim();
                if (newHomeAddress.isEmpty()) {
                    newHomeAddress = currentHomeAddress;
                } else if (newHomeAddress.equalsIgnoreCase("NULL")) {
                    System.err.println("HomeAddress is NOT NULL, keeping current value.");
                    newHomeAddress = currentHomeAddress;
                }

                System.out.print("Enter New TimeOfEmployment [" + currentTimeOfEmployment + "]: ");
                String toeInput = scanner.nextLine().trim();
                Integer newTimeOfEmployment = toeInput.isEmpty() 
                    ? currentTimeOfEmployment 
                    : toeInput.equalsIgnoreCase("NULL") 
                        ? null 
                        : Integer.parseInt(toeInput);

                // update
                StringBuilder sqlUpdate = new StringBuilder("UPDATE Staff SET ");
                boolean first = true;

                if (newStoreID == null || !newStoreID.equals(currentStoreID)) {
                    sqlUpdate.append(first ? "" : ", ").append("StoreID = ?");
                    first = false;
                }
                if (!newJobTitle.equals(currentJobTitle)) {
                    sqlUpdate.append(first ? "" : ", ").append("JobTitle = ?");
                    first = false;
                }
                if (!newName.equals(currentName)) {
                    sqlUpdate.append(first ? "" : ", ").append("Name = ?");
                    first = false;
                }
                if (newAge == null || !newAge.equals(currentAge)) {
                    sqlUpdate.append(first ? "" : ", ").append("Age = ?");
                    first = false;
                }
                if (!newPhoneNumber.equals(currentPhoneNumber)) {
                    sqlUpdate.append(first ? "" : ", ").append("PhoneNumber = ?");
                    first = false;
                }
                if (!newEmail.equals(currentEmail)) {
                    sqlUpdate.append(first ? "" : ", ").append("Email = ?");
                    first = false;
                }
                if (!newHomeAddress.equals(currentHomeAddress)) {
                    sqlUpdate.append(first ? "" : ", ").append("HomeAddress = ?");
                    first = false;
                }
                if (newTimeOfEmployment == null || !newTimeOfEmployment.equals(currentTimeOfEmployment)) {
                    sqlUpdate.append(first ? "" : ", ").append("TimeOfEmployment = ?");
                    first = false;
                }

                if (first) {
                    System.out.println("No changes detected. Nothing to update.");
                    return;
                }

                sqlUpdate.append(" WHERE StaffID = ?");

                // 执行 UPDATE
                try (PreparedStatement updateStmt = conn.prepareStatement(sqlUpdate.toString())) {
                    int idx = 1;
                    if (newStoreID == null || !newStoreID.equals(currentStoreID)) {
                        if (newStoreID == null) {
                            updateStmt.setNull(idx++, Types.INTEGER);
                        } else {
                            updateStmt.setInt(idx++, newStoreID);
                        }
                    }
                    if (!newJobTitle.equals(currentJobTitle)) {
                        updateStmt.setString(idx++, newJobTitle);
                    }
                    if (!newName.equals(currentName)) {
                        updateStmt.setString(idx++, newName);
                    }
                    if (newAge == null || !newAge.equals(currentAge)) {
                        if (newAge == null) {
                            updateStmt.setNull(idx++, Types.INTEGER);
                        } else {
                            updateStmt.setInt(idx++, newAge);
                        }
                    }
                    if (!newPhoneNumber.equals(currentPhoneNumber)) {
                        updateStmt.setString(idx++, newPhoneNumber);
                    }
                    if (!newEmail.equals(currentEmail)) {
                        updateStmt.setString(idx++, newEmail);
                    }
                    if (!newHomeAddress.equals(currentHomeAddress)) {
                        updateStmt.setString(idx++, newHomeAddress);
                    }
                    if (newTimeOfEmployment == null || !newTimeOfEmployment.equals(currentTimeOfEmployment)) {
                        if (newTimeOfEmployment == null) {
                            updateStmt.setNull(idx++, Types.INTEGER);
                        } else {
                            updateStmt.setInt(idx++, newTimeOfEmployment);
                        }
                    }
                    updateStmt.setInt(idx, staffID);

                    int rowsAffected = updateStmt.executeUpdate();
                    if (rowsAffected > 0) {
                        System.out.println("Successfully updated Staff information.");
                    } else {
                        System.out.println("No rows were updated.");
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
