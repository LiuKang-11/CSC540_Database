package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

/**
 * This class handles the update of store information.
 * It prompts the user for a StoreID and new values for ManagerID, StoreAddress, and PhoneNumber.
 * It then updates the corresponding record in the Store table.
 */
public class UpdateStoreInfo {
    public static void updateStoreInfo() {
        Scanner scanner = new Scanner(System.in);
        
        // Get storeID (required)
        System.out.print("Enter StoreID: ");
        int storeID;
        try {
            storeID = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid StoreID format. Must be a number.");
            return;
        }

        // First, get current values to show user
        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                 "SELECT ManagerID, StoreAddress, PhoneNumber " +
                 "FROM Store WHERE StoreID = ?")) {
            
            ps.setInt(1, storeID);
            ResultSet rs = ps.executeQuery();
            
            if (!rs.next()) {
                System.err.println("StoreID with ID " + storeID + " not found.");
                return;
            }
            
            // Store current values
            String currentManagerID = rs.getString("ManagerID");
            String currentStoreAddress = rs.getString("StoreAddress");
            String currentPhoneNumber = rs.getString("PhoneNumber");
            
            // Display current values
            System.out.println("\nCurrent Store Information:");
            System.out.println("1. ManagerID: " + currentManagerID);
            System.out.println("2. Store Address: " + currentStoreAddress);
            System.out.println("3. Phone Number: " + currentPhoneNumber);
            System.out.println("\nEnter new values (press Enter to keep current value, type 'NULL' to set to null)");
            
            // Get updates for each field
            System.out.print("Enter New ManagerID [" + currentManagerID + "]: ");
            String newManagerID = scanner.nextLine().trim();
            if (newManagerID.isEmpty()) {
                newManagerID = currentManagerID;
            } else if (newManagerID.equalsIgnoreCase("NULL")) {
                newManagerID = "NULL";
            }

            System.out.print("Enter New Store Address [" + currentStoreAddress + "]: ");
            String newStoreAddress = scanner.nextLine().trim();
            if (newStoreAddress.isEmpty()) {
                newStoreAddress = currentStoreAddress;
            } else if (newStoreAddress.equalsIgnoreCase("NULL")) {
                System.err.println("Store Address cannot be NULL (it's a NOT NULL field). Keeping current value.");
                newStoreAddress = currentStoreAddress;
            }

            System.out.print("Enter New Phone Number [" + currentPhoneNumber + "]: ");
            String newPhoneNumber = scanner.nextLine().trim();
            if (newPhoneNumber.isEmpty()) {
                newPhoneNumber = currentPhoneNumber;
            } else if (newPhoneNumber.equalsIgnoreCase("NULL")) {
                System.err.println("Phone Number cannot be NULL (it's a NOT NULL field). Keeping current value.");
                newPhoneNumber = currentPhoneNumber;
            }

            // Build dynamic UPDATE statement
            StringBuilder sql = new StringBuilder("UPDATE Store SET ");
            boolean first = true;
            
            if (newManagerID.equals("NULL")) {
                sql.append(first ? "" : ", ").append("ManagerID = NULL");
                first = false;
            } else if (!newManagerID.equals(currentManagerID)) {
                sql.append(first ? "" : ", ").append("ManagerID = ?");
                first = false;
            }
            
            if (!newStoreAddress.equals(currentStoreAddress)) {
                sql.append(first ? "" : ", ").append("StoreAddress = ?");
                first = false;
            }
            
            if (newPhoneNumber.equals("NULL")) {
                sql.append(first ? "" : ", ").append("PhoneNumber = NULL");
                first = false;
            } else if (!newPhoneNumber.equals(currentPhoneNumber)) {
                sql.append(first ? "" : ", ").append("PhoneNumber = ?");
                first = false;
            }
            
            // If nothing changed
            if (first) {
                System.out.println("No changes detected. Nothing to update.");
                return;
            }
            
            sql.append(" WHERE StoreID = ?");
            
            // Execute the update
            try (PreparedStatement updateStmt = conn.prepareStatement(sql.toString())) {
                int paramIndex = 1;
                
                if (!newManagerID.equals(currentManagerID)) {
                    updateStmt.setString(paramIndex++, newManagerID);
                }
                
                if (!newStoreAddress.equals(currentStoreAddress)) {
                    updateStmt.setString(paramIndex++, newStoreAddress);
                }
                
                if (!newPhoneNumber.equals(currentPhoneNumber)) {
                    updateStmt.setString(paramIndex++, newPhoneNumber);
                }
                
                updateStmt.setInt(paramIndex, storeID);
                
                int rowsAffected = updateStmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Successfully updated Store information.");
                } else {
                    System.out.println("No rows were updated.");
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}