package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import java.util.Scanner;

/**
 * This class handles the creation of merchandise information.
 * It prompts the user for necessary details and inserts them into the Merchandise table.
 */
public class createMerchInfo {

    public static void createMerchInfo(Scanner scanner) {
        System.out.print("Please enter Product Name: ");
        String productName = scanner.nextLine().trim();

        System.out.print("Please enter Product's Buying Price: ");
        double buyPrice = Double.parseDouble(scanner.nextLine().trim());

        System.out.print("Please enter Product's Market Price: ");
        double marketPrice = Double.parseDouble(scanner.nextLine().trim());

        System.out.print("Please enter Supplier ID: ");
        int supplierID = Integer.parseInt(scanner.nextLine().trim());

        System.out.print("Please enter Product's Production Date (YYYY-MM-DD): ");
        Date productionDate = Date.valueOf(scanner.nextLine().trim());

        System.out.print("Please enter Product's Expiration Date (YYYY-MM-DD): ");
        Date expirationDate = Date.valueOf(scanner.nextLine().trim());

        String sql = 
            "INSERT INTO Merchandise " +
            "(ProductName, BuyPrice, MarketPrice, SupplierID, ProductionDate, ExpirationDate) " +
            "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, productName);
            ps.setDouble(2, buyPrice);
            ps.setDouble(3, marketPrice);
            ps.setInt(4, supplierID);
            ps.setDate(5, productionDate);
            ps.setDate(6, expirationDate);

            int affected = ps.executeUpdate();
            if (affected > 0) {
                System.out.println("===== Merchandise Info =====");
                System.out.println("Product inserted successfully.");
            } else {
                System.out.println("No row was inserted.");
            }

        } catch (SQLException e) {
            System.err.println("Error inserting merchandise: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
