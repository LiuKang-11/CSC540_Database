package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the creation of staff information.
 * It prompts the user for necessary details and inserts them into the Staff table.
 */
public class createStaffInfo {


    public static void createStaff(Scanner scanner) {
        // read input
        System.out.print("Please enter StoreID: ");
        int storeID = Integer.parseInt(scanner.nextLine().trim());
        
        System.out.print("Please enter JobTitle (Manager/Assistant Manager/Cashier/Warehouse Checker/Billing Staff): ");
        String jobTitle = scanner.nextLine().trim();
        
        System.out.print("Please enter Staff Name: ");
        String name = scanner.nextLine().trim();
        
        System.out.print("Please enter Staff Age: ");
        int age = Integer.parseInt(scanner.nextLine().trim());
        
        System.out.print("Please enter PhoneNumber: ");
        String phoneNumber = scanner.nextLine().trim();
        
        System.out.print("Please enter Email: ");
        String email = scanner.nextLine().trim();
        
        System.out.print("Please enter HomeAddress: ");
        String homeAddress = scanner.nextLine().trim();
        
        System.out.print("Please enter TimeOfEmployment (year): ");
        int timeOfEmployment = Integer.parseInt(scanner.nextLine().trim());
        
        // SQL insert
        String sql = "INSERT INTO Staff (StoreID, JobTitle, Name, Age, PhoneNumber, Email, HomeAddress, TimeOfEmployment) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setInt(1, storeID);
            ps.setString(2, jobTitle);
            ps.setString(3, name);
            ps.setInt(4, age);
            ps.setString(5, phoneNumber);
            ps.setString(6, email);
            ps.setString(7, homeAddress);
            ps.setInt(8, timeOfEmployment);

            int affected = ps.executeUpdate();
            if (affected > 0) {
                System.out.println("Staff member inserted successfully!");
            } else {
                System.out.println("No rows were inserted.");
            }
        } catch (SQLException e) {
            System.err.println("Error inserting staff: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
