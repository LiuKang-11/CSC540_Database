package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

/**
 * This class handles the creation of a new store.
 * It prompts the user for necessary information and inserts it into the Store table.
 */
public class createStore {

  
    public static void createStore(Scanner scanner) {
        System.out.print("Please enter Manager ID (or 0 if none): ");
        String mgrInput = scanner.nextLine().trim();
        int managerID;
        try {
            managerID = Integer.parseInt(mgrInput);
        } catch (NumberFormatException e) {
            System.err.println("Invalid Manager ID format.");
            return;
        }

        System.out.print("Please enter Store Address: ");
        String storeAddress = scanner.nextLine().trim();

        System.out.print("Please enter Phone Number: ");
        String phoneNumber = scanner.nextLine().trim();

        String sql = 
            "INSERT INTO Store (ManagerID, StoreAddress, PhoneNumber) " +
            "VALUES (?, ?, ?)";

        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                 sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            // 如果输入 0，则在数据库中写 NULL
            if (managerID == 0) {
                ps.setNull(1, Types.INTEGER);
            } else {
                ps.setInt(1, managerID);
            }

            ps.setString(2, storeAddress);
            ps.setString(3, phoneNumber);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("Failed to create store record.");
                return;
            }

            System.out.println("Store created successfully!");

            // 读取自动生成的 StoreID
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    int newStoreID = keys.getInt(1);
                    System.out.println("New StoreID: " + newStoreID);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error creating store: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
