package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

/**
 * This class handles the creation of a new supplier.
 * It prompts the user for necessary information and inserts it into the Supplier table.
 */
public class createSupplier {

    public static void createSupplier(Scanner scanner) {
        System.out.print("Please enter Supplier Name: ");
        String name = scanner.nextLine().trim();

        System.out.print("Please enter Supplier Location: ");
        String location = scanner.nextLine().trim();

        System.out.print("Please enter Phone Number: ");
        String phoneNumber = scanner.nextLine().trim();

        System.out.print("Please enter Email: ");
        String email = scanner.nextLine().trim();

        String sql = 
            "INSERT INTO Supplier (Name, Location, PhoneNumber, Email) " +
            "VALUES (?, ?, ?, ?)";

        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                 sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, name);
            ps.setString(2, location);
            ps.setString(3, phoneNumber);
            ps.setString(4, email);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("Failed to create supplier record.");
                return;
            }

            System.out.println("Supplier created successfully!");

            // read SupplierID
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    int newSupplierID = keys.getInt(1);
                    System.out.println("New SupplierID: " + newSupplierID);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error creating supplier: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
