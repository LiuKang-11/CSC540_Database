-- Store Table

CREATE TABLE Store (
    StoreID INT AUTO_INCREMENT PRIMARY KEY,
    ManagerID INT NULL,
    StoreAddress VARCHAR(255) NOT NULL,
    PhoneNumber VARCHAR(15) NULL,
    FOREIGN KEY (ManagerID) REFERENCES Staff(StaffID) ON DELETE SET NULL
);
-- Staff Table
CREATE TABLE Staff (
    StaffID INT AUTO_INCREMENT PRIMARY KEY,
    StoreID INT NOT NULL,
    JobTitle VARCHAR(50) NOT NULL,
    Name VARCHAR(100) NOT NULL,
    Age INT NOT NULL,
    PhoneNumber VARCHAR(15) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    HomeAddress VARCHAR(255) NOT NULL,
    TimeOfEmployment INT NOT NULL DEFAULT 0,
    FOREIGN KEY (StoreID) REFERENCES Store(StoreID) ON DELETE CASCADE
);

-- AdminStaff Table
CREATE TABLE AdminStaff (
    StaffID INT PRIMARY KEY,
    FOREIGN KEY (StaffID) REFERENCES Staff(StaffID) ON DELETE CASCADE
);

-- RegistrationStaff Table
CREATE TABLE RegistrationStaff (
    StaffID INT PRIMARY KEY,
    FOREIGN KEY (StaffID) REFERENCES Staff(StaffID) ON DELETE CASCADE
);

-- WarehouseStaff Table
CREATE TABLE WarehouseStaff (
    StaffID INT PRIMARY KEY,
    FOREIGN KEY (StaffID) REFERENCES Staff(StaffID) ON DELETE CASCADE
);

-- BillingStaff Table
CREATE TABLE BillingStaff (
    StaffID INT PRIMARY KEY,
    FOREIGN KEY (StaffID) REFERENCES Staff(StaffID) ON DELETE CASCADE
);

-- Cashier Table
CREATE TABLE Cashier (
    StaffID INT PRIMARY KEY,
    FOREIGN KEY (StaffID) REFERENCES Staff(StaffID) ON DELETE CASCADE
);

-- ClubMember Table
CREATE TABLE ClubMember (
    CustomerID INT AUTO_INCREMENT PRIMARY KEY,
    Email VARCHAR(100) NOT NULL,
    PhoneNumber VARCHAR(15) NOT NULL,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    HomeAddress VARCHAR(255) NOT NULL,
    MembershipLevel VARCHAR(50) NOT NULL,
    ActiveStatus BOOLEAN NOT NULL DEFAULT TRUE
);

-- Supplier Table
CREATE TABLE Supplier (
    SupplierID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Location VARCHAR(255) NOT NULL,
    PhoneNumber VARCHAR(15) NOT NULL,
    Email VARCHAR(100) NOT NULL
);

-- Merchandise Table
CREATE TABLE Merchandise (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    BuyPrice DECIMAL(10, 2) NOT NULL,
    MarketPrice DECIMAL(10, 2) NOT NULL,
    SupplierID INT NOT NULL,
    ProductionDate DATE NOT NULL,
    ExpirationDate DATE NOT NULL,
    FOREIGN KEY (SupplierID) REFERENCES Supplier(SupplierID) ON DELETE CASCADE
);

-- Inventory Table
CREATE TABLE Inventory (
    StoreID INT,
    ProductID INT,
    Quantity INT NOT NULL,
    DiscountInfo DECIMAL(2, 0),
    valid_from DATE,
    valid_to DATE,
    PRIMARY KEY (StoreID, ProductID),
    FOREIGN KEY (StoreID) REFERENCES Store(StoreID) ON DELETE CASCADE,
    FOREIGN KEY (ProductID) REFERENCES Merchandise(ProductID) ON DELETE CASCADE
);

-- SignUp Table
CREATE TABLE SignUp (
    StaffID INT,
    CustomerID INT,
    SignUpNumber SERIAL, 
    Date Date, 
    StoreID INT NOT NULL,
    PRIMARY KEY (StaffID, CustomerID, SignUpNumber),
    FOREIGN KEY (StaffID) REFERENCES RegistrationStaff(StaffID) ON DELETE CASCADE,
    FOREIGN KEY (CustomerID) REFERENCES ClubMember(CustomerID) ON DELETE CASCADE,
    FOREIGN KEY (StoreID) REFERENCES Store(StoreID) ON DELETE CASCADE
);

-- Cancel Table
CREATE TABLE Cancel (
    StaffID INT,
    CustomerID INT,
    CancelNumber SERIAL,
    Date Date,
    PRIMARY KEY (StaffID, CustomerID, CancelNumber),
    FOREIGN KEY (StaffID) REFERENCES RegistrationStaff(StaffID) ON DELETE CASCADE,
    FOREIGN KEY (CustomerID) REFERENCES ClubMember(CustomerID) ON DELETE CASCADE
);

-- Transfer Table
CREATE TABLE Transfer (
    Store1ID INT,
    Store2ID INT,
    Product1ID INT,
    Product2ID INT,
    Date Date,
    StaffID INT NOT NULL,
    Quantity INT NOT NULL,
    TransferNumber SERIAL,
    PRIMARY KEY (Store1ID, Store2ID, Product1ID, Product2ID, TransferNumber),
    FOREIGN KEY (Store1ID) REFERENCES Store(StoreID) ON DELETE CASCADE,
    FOREIGN KEY (StaffID) REFERENCES WarehouseStaff(StaffID) ON DELETE CASCADE,
    FOREIGN KEY (Store2ID) REFERENCES Store(StoreID) ON DELETE CASCADE,
    FOREIGN KEY (Product1ID) REFERENCES Merchandise(ProductID) ON DELETE CASCADE,
    FOREIGN KEY (Product2ID) REFERENCES Merchandise(ProductID) ON DELETE CASCADE
);

-- Order Table
CREATE TABLE Orders (
    StoreID INT,
    SupplierID INT,
    ProductID INT,
    StaffID INT NOT NULL,
    Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Quantity INT NOT NULL,
    BuyPrice DECIMAL(10, 2) NOT NULL,
    OrderNumber SERIAL,
    PRIMARY KEY (StoreID, SupplierID, ProductID, OrderNumber),
    FOREIGN KEY (StoreID) REFERENCES Store(StoreID) ON DELETE CASCADE,
    FOREIGN KEY (SupplierID) REFERENCES Supplier(SupplierID) ON DELETE CASCADE,
    FOREIGN KEY (ProductID) REFERENCES Merchandise(ProductID) ON DELETE CASCADE,
    FOREIGN KEY (StaffID) REFERENCES WarehouseStaff(StaffID) ON DELETE CASCADE
);

-- Return Table
CREATE TABLE Returns (
    StoreID INT,
    ProductID INT,
    StaffID INT NOT NULL,
    CustomerID INT NOT NULL,
    Date Date,
    Quantity INT NOT NULL,
    ReturnNumber SERIAL,
    PRIMARY KEY (StoreID, ProductID, ReturnNumber),
    FOREIGN KEY (StoreID) REFERENCES Store(StoreID) ON DELETE CASCADE,
    FOREIGN KEY (ProductID) REFERENCES Merchandise(ProductID) ON DELETE CASCADE,
    FOREIGN KEY (StaffID) REFERENCES WarehouseStaff(StaffID) ON DELETE CASCADE,
    FOREIGN KEY (CustomerID) REFERENCES ClubMember(CustomerID) ON DELETE CASCADE
);

-- Transaction Table
CALL p_createTransaction(1002, 502, 203, 301, 5);
CREATE TABLE Transaction (
    StoreID INT,
    CustomerID INT,
    StaffID INT,
    ProductID INT,
    Quantity INT NOT NULL,
    TotalPrice DECIMAL(10, 2) NOT NULL,
    PurchaseDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    TransactionNumber SERIAL,
    PRIMARY KEY (StoreID, CustomerID, StaffID, ProductID, TransactionNumber),
    FOREIGN KEY (StoreID) REFERENCES Store(StoreID) ON DELETE CASCADE,
    FOREIGN KEY (CustomerID) REFERENCES ClubMember(CustomerID) ON DELETE CASCADE,
    FOREIGN KEY (StaffID) REFERENCES Cashier(StaffID) ON DELETE CASCADE,
    FOREIGN KEY (ProductID) REFERENCES Merchandise(ProductID) ON DELETE CASCADE
);