package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the deletion of merchandise information.
 * It prompts the user for a Product ID and deletes the corresponding record from the Merchandise table.
 */
public class deleteMerchInfo {

    public static void deleteMerchInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter Product ID: ");
        int ProductID = scanner.nextInt();
        scanner.nextLine(); 
        
        String sql = "Delete FROM Merchandise WHERE ProductID = ?";
        
        try (Connection conn = Main.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setInt(1, ProductID); 
            
            System.out.print("Are you sure you want to delete the Product with ProductID = " + ProductID + "? (yes/no): ");
            String confirmation = scanner.nextLine();
            if (confirmation.equalsIgnoreCase("yes")) {
                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Product with ProductID = " + ProductID + " has been deleted.");
                } else {
                    System.out.println("Error: Can't find the Product with ProductID = " + ProductID);
                }
            } else {
                System.out.println("Deletion cancelled.");
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}