package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the deletion of supplier information.
 * It prompts the user for a Supplier ID and deletes the corresponding record from the Supplier table.
 */
public class deleteSupplierInfo {

    public static void deleteSupplierInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter Supplier ID: ");
        int SupplierID = scanner.nextInt();
        scanner.nextLine(); 
        
        String sql = "Delete FROM Supplier WHERE SupplierID = ?";
        
        try (Connection conn = Main.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setInt(1, SupplierID); 
            
            System.out.print("Are you sure you want to delete the Supplier with SupplierID = " + SupplierID + "? (yes/no): ");
            String confirmation = scanner.nextLine();
            if (confirmation.equalsIgnoreCase("yes")) {
                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Supplier with SupplierID = " + SupplierID + " has been deleted.");
                } else {
                    System.out.println("Error: Can't find the Supplier with SupplierID = " + SupplierID);
                }
            } else {
                System.out.println("Deletion cancelled.");
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}