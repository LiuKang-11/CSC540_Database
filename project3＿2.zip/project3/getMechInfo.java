package project3;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the retrieval of merchandise information.
 * It prompts the user for a Product ID and retrieves the corresponding merchandise details from the database.
 */
public class getMechInfo {


    public static void getMerchInfo(Scanner scanner) {
        System.out.print("Please enter Product ID: ");
        int productID;
        try {
            productID = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid Product ID format.");
            return;
        }

        String sql = 
            "SELECT * FROM Merchandise WHERE ProductID = ?";

        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, productID);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    System.out.println("===== Merchandise Info =====");
                    System.out.println("ProductID      : " + rs.getInt("ProductID"));
                    System.out.println("ProductName    : " + rs.getString("ProductName"));
                    System.out.println("BuyPrice       : " + rs.getDouble("BuyPrice"));
                    System.out.println("MarketPrice    : " + rs.getDouble("MarketPrice"));
                    System.out.println("SupplierID     : " + rs.getInt("SupplierID"));
                    Date prodDate  = rs.getDate("ProductionDate");
                    Date expDate   = rs.getDate("ExpirationDate");
                    System.out.println("ProductionDate : " + (prodDate != null ? prodDate.toString() : "NULL"));
                    System.out.println("ExpirationDate : " + (expDate  != null ? expDate.toString()  : "NULL"));
                    System.out.println("=============================");
                } else {
                    System.out.println("No merchandise found with ProductID = " + productID);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error querying merchandise: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
