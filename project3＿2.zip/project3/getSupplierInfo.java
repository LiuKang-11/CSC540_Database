package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * This class handles the retrieval of supplier information.
 * It prompts the user for a Supplier ID and retrieves the corresponding supplier details from the database.
 */
public class getSupplierInfo {

    public static void getSupplierInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter Supplier ID: ");
        int SupplierID = scanner.nextInt();
        scanner.nextLine(); 
        
        String sql = "SELECT *" +
                     "FROM Supplier WHERE SupplierID = ?";
        
        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setInt(1, SupplierID); 
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    System.out.println("===== Supplier Info =====");
                    System.out.println("SupplierID: " + rs.getInt("SupplierID"));
                    System.out.println("Supplier Name: " + rs.getString("Name"));
                    System.out.println("Supplier Location: " + rs.getString("Location"));
                    System.out.println("PhoneNumber: " + rs.getString("PhoneNumber"));
                    System.out.println("Email: " + rs.getString("Email"));
                    
                    System.out.println("=====================");
                } else {
                    System.out.println("Error: Can't find the Supplier with SupplierID =" + SupplierID);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}