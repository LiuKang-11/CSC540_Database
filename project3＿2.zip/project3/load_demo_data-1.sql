INSERT INTO Store (StoreID, ManagerID, StoreAddress, PhoneNumber) 
VALUES
(1001, NULL, '1021 Main Campus Dr Raleigh, NC, 27606', 9194789124),
(1002, NULL, '851 Partners Way Raleigh, NC, 27606', 9195929621);

--201

INSERT INTO Staff (StaffID, StoreID, JobTitle, Name, Age, PhoneNumber, Email, HomeAddress, TimeOfEmployment)
VALUES
(201, 1001, 'Manager', 'Alice Johnson', 34, 9194285357, 'alice.johson@gmail.com', '111 Wolf Street, Raleigh, NC 27606', 5),
(202, 1002, 'Assistant Manager', 'Bob Smith', 29, 9841482375, 'bob.smith@hotmail.com', '222 Fox Ave, Durham, NC 27701', 3),
(203, 1001, 'Cashier', 'Charlie Davis', 40, 9194856193, 'charlie.davis@gmail.com', '333 Bear Rd,Greensboro, NC 27282', 7),
(204, 1002, 'Warehouse Checker', 'David Lee', 45, 9847028471, 'david.lee@yahoo.com', '444 Eagle Dr, Raleigh, NC 27606', 10),
(205, 1001, 'Billing Staff', 'Emma White', 30, 9198247184, 'emma.white@gmail.com', '555 Deer Ln,Durham, NC 27560', 4),
(206, 1002, 'Billing Staff', 'Frank Harris', 38, 919428535, 'frank.harris@gmail.com', '666 Owl Ct, Raleigh, NC 27610', 6),
(207, 1001, 'Warehouse Checker', 'Isla Scott', 33, 9841298427, 'isla.scott@gmail.com', '777 Lynx Rd, Raleigh, NC 27612', 2),
(208, 1002, 'Cashier', 'Jack Lewis', 41, 9194183951, 'jack.lewis@gmail.com', '888 Falcon St, Greensboro, NC 27377', 3);

INSERT INTO Merchandise (ProductID, ProductName, BuyPrice, MarketPrice, SupplierID, ProductionDate, ExpirationDate)
VALUES
(301, 'Organic Apples', 1.5, 2, 401, '2025-04-12', '2025-04-20'),
(302, 'Whole Grain Bread', 2, 3.5, 401, '2025-04-10', '2025-04-15'),
(303, 'Almond Milk', 3.5, 4, 401, '2025-04-15', '2025-04-30'),
(304, 'Brown Rice', 2.8, 3.5, 402, '2025-04-12', '2026-04-20'),
(305, 'Olive Oil', 5, 7, 402, '2025-04-04', '2027-04-20'),
(306, 'Whole Chicken', 10, 13, 402, '2025-04-12', '2025-05-12'),
(307, 'Cheddar Cheese', 3, 4.2, 402, '2025-04-12', '2025-10-12'),
(308, 'Dark Chocolate', 2.5, 3.5, 402, '2025-04-12', '2026-06-20');


insert into Supplier(SupplierID, Name, Location, PhoneNumber, Email) 
values (401, 'Fresh Farms Ltd.', '123 Greenway Blvd, Raleigh, NC 27615', '9194248251', 'contact@freshfarms.com');
insert into Supplier(SupplierID, Name, Location, PhoneNumber, Email) 
values (402, 'Organic Good Inc.', '456 Healthy Rd, Raleigh, NC 27606', '9841384298', 'info@orgaincgoods.com');


// Club Member

-- ClubMember Table
CREATE TABLE ClubMember (
   CustomerID INT AUTO_INCREMENT PRIMARY KEY,
   Email VARCHAR(100) NOT NULL,
   PhoneNumber VARCHAR(15) NOT NULL,
   FirstName VARCHAR(50) NOT NULL,
   LastName VARCHAR(50) NOT NULL,
   HomeAddress VARCHAR(255) NOT NULL,
   MembershipLevel VARCHAR(50) NOT NULL,
   ActiveStatus BOOLEAN NOT NULL DEFAULT TRUE
);


-- 設定 ClubMember 表的 AUTO_INCREMENT 起始值為 501
ALTER TABLE ClubMember AUTO_INCREMENT = 501;


-- 建立 Club Member #1 (Active)
CALL p_createClubMemberInfo(
   'John',              -- firstName
   'Doe',               -- lastName
   'Gold',              -- membershipLevel
   'john.doe@gmail.com',-- email
   '9194285314',        -- phoneNumber
   '12 Elm St, Raleigh, NC 27607', -- homeAddress
   202,                 -- registrationStaffID
   1002                 -- storeID
);


-- 建立 Club Member #2 (預設 Active，之後更新成 Inactive)
CALL p_createClubMemberInfo(
   'Emily',
   'Smith',
   'Silver',
   'emily.smith@gmail.com',
   '9844235314',
   '34 Oak Ave, Raleigh, NC 27606',
   202,
   1002
);


-- 建立 Club Member #3 (Active)
CALL p_createClubMemberInfo(
   'Michael',
   'Brown',
   'Platinum',
   'michael.brown@gmail.com',
   '9194820931',
   '56 Pine Rd, Raleigh, NC 27607',
   202,
   1002
);


-- 建立 Club Member #4 (Active)
CALL p_createClubMemberInfo(
   'Sarah',
   'Johnson',
   'Gold',
   'sarah.johnson@gmail.com',
   '9841298435',
   '78 Maple Dr, Raleigh, NC 27607',
   202,
   1002
);


-- 建立 Club Member #5 (預設 Active，之後更新成 Inactive)
CALL p_createClubMemberInfo(
   'David',
   'Williams',
   'Silver',
   'david.williams@gmail.com',
   '9194829424',
   '90 Birch Ln, Raleigh, NC 27607',
   202,
   1002
);


-- 建立 Club Member #6 (Active)
CALL p_createClubMemberInfo(
   'Anna',
   'Miller',
   'Platinum',
   'anna.miller@gmail.com',
   '9848519427',
   '101 Oak Ct, Raleigh, NC 27607',
   202,
   1002
);


-- 更新需為 Inactive 的記錄 (Club Member #2 與 Club Member #5)
UPDATE ClubMember
SET ActiveStatus = FALSE
WHERE CustomerID IN (502, 505);



//Transaction
    IN pStoreID INT,
    IN pCustomerID INT,
    IN pCashierID INT,
    IN pProductID INT,
    IN pQuantity INT


-- p_createOrders(StoreID, SupplierID, ProductID, StaffID, Quantity, BuyPrice);
CALL p_createOrders(1002, 401, 301, 204, 120, 1.5);
CALL p_createOrders(1002, 401, 302, 204, 80, 2);
CALL p_createOrders(1002, 401, 303, 204, 150, 3.5);
CALL p_createOrders(1002, 402, 304, 204, 200, 2.8);
CALL p_createOrders(1002, 402, 305, 204, 90, 5);
CALL p_createOrders(1002, 402, 306, 204, 120, 10);
CALL p_createOrders(1002, 402, 307, 204, 60, 3);
CALL p_createOrders(1002, 402, 308, 204, 50, 2.5);

-- p_updateInventoryDiscount(StoreID, ProductID, DiscountInfo, ValidFrom, ValidTo)
CALL p_updateInventoryDiscount(1001, 306, 10, '2024-04-10', '2024-05-10');
CALL p_updateInventoryDiscount(1001, 303, 20, '2023-02-12', '2023-02-19');
CALL p_updateInventoryDiscount(1002, 306, 10, '2024-04-10', '2024-05-10');
CALL p_updateInventoryDiscount(1002, 303, 20, '2023-02-12', '2023-02-19');

-- set the club member to active to enter the transaction
update ClubMember set ActiveStatus=1 where CustomerID=502;


-- 交易 #1, 商品1: Organic Apples
CALL p_createTransaction(1002, 502, 203, 301, 5);
-- '2024-02-10 00:00:00'
-- 交易 #1, 商品2: Whole Grain Bread
CALL p_createTransaction(1002, 502, 203, 302, 10);
--, '2024-02-10 00:00:00'
-- 交易 #2, 商品1: Almond Milk
CALL p_createTransaction(1002, 502, 208, 303, 9);
--, '2024-09-12 00:00:00'
-- 交易 #2, 商品2: Brown Rice
CALL p_createTransaction(1002, 502, 208, 304, 3);
--, '2024-09-12 00:00:00'
-- 交易 #2, 商品3: Olive Oil
CALL p_createTransaction(1002, 502, 208, 305, 3);
--, '2024-09-12 00:00:00'

-- 交易 #3, 商品1: Dark Chocolate
CALL p_createTransaction(1002, 502, 208, 308, 5);
--, '2024-09-23 00:00:00'
-- 交易 #3, 商品2: Olive Oil
CALL p_createTransaction(1002, 502, 208, 305, 6);
--, '2024-09-23 00:00:00'
-- 交易 #3, 商品3: Almond Milk
CALL p_createTransaction(1002, 502, 208, 303, 7);
--, '2024-09-23 00:00:00'
-- 交易 #4, 商品: Whole Chicken
CALL p_createTransaction(1002, 504, 208, 306, 3);
--, '2024-07-23 00:00:00'


update ClubMember set ActiveStatus=0 where CustomerID=502;


-- update Transaction change the transaction date and transaction number
UPDATE Transaction
SET PurchaseDate = '2024-02-10 00:00:00', TransactionNumber = 701
WHERE StoreID = 1002 AND CustomerID = 502 AND StaffID = 203 AND ProductID = 301 AND Quantity = 5;
UPDATE Transaction
SET PurchaseDate = '2024-02-10 00:00:00', TransactionNumber = 702
WHERE StoreID = 1002 AND CustomerID = 502 AND StaffID = 203 AND ProductID = 302 AND Quantity = 10;
UPDATE Transaction
SET PurchaseDate = '2024-09-12 00:00:00', TransactionNumber = 703
WHERE StoreID = 1002 AND CustomerID = 502 AND StaffID = 208 AND ProductID = 303 AND Quantity = 9;
UPDATE Transaction
SET PurchaseDate = '2024-09-12 00:00:00', TransactionNumber = 704
WHERE StoreID = 1002 AND CustomerID = 502 AND StaffID = 208 AND ProductID = 304 AND Quantity = 3;
UPDATE Transaction
SET PurchaseDate = '2024-09-12 00:00:00', TransactionNumber = 705
WHERE StoreID = 1002 AND CustomerID = 502 AND StaffID = 208 AND ProductID = 305 AND Quantity = 3;
UPDATE Transaction
SET PurchaseDate = '2024-09-23 00:00:00', TransactionNumber = 706
WHERE StoreID = 1002 AND CustomerID = 502 AND StaffID = 208 AND ProductID = 308 AND Quantity = 5;
UPDATE Transaction
SET PurchaseDate = '2024-09-23 00:00:00', TransactionNumber = 707
WHERE StoreID = 1002 AND CustomerID = 502 AND StaffID = 208 AND ProductID = 305 AND Quantity = 6;
UPDATE Transaction
SET PurchaseDate = '2024-09-23 00:00:00', TransactionNumber = 708
WHERE StoreID = 1002 AND CustomerID = 502 AND StaffID = 208 AND ProductID = 303 AND Quantity = 7;
UPDATE Transaction
SET PurchaseDate = '2024-07-23 00:00:00', TransactionNumber = 709
WHERE StoreID = 1002 AND CustomerID = 504 AND StaffID = 208 AND ProductID = 306 AND Quantity = 3;

update Store set ManagerID = 201 where StoreID = 1001;