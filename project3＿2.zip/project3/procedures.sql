/*
===========================================================
Procedure Name : p_createClubMemberInfo
Create Date    : 2025-04-06
Last Modified  : 2025-04-06
Goal           : Create a new club member record and record the corresponding sign-up details.
Input Params   : 
                 p_firstName VARCHAR(50)   - Member's first name
                 p_lastName VARCHAR(50)    - Member's last name
                 p_membershipLevel VARCHAR(50) - Membership level (e.g., bronze, silver, platinum)
                 p_email VARCHAR(100)      - Member's email address
                 p_phoneNumber VARCHAR(15) - Member's phone number
                 p_homeAddress VARCHAR(255)- Member's home address
                 p_staffID INT             - ID of the staff handling the sign-up
                 p_storeID INT             - ID of the store where sign-up occurs
Output         : Inserts a record into ClubMember and a related record into SignUp using LAST_INSERT_ID()
===========================================================
*/
DELIMITER $$ 
CREATE PROCEDURE p_createClubMemberInfo(
    IN p_firstName VARCHAR(50),
    IN p_lastName VARCHAR(50),
    IN p_membershipLevel VARCHAR(50),
    IN p_email VARCHAR(100),
    IN p_phoneNumber VARCHAR(15),
    IN p_homeAddress VARCHAR(255),
    IN p_staffID INT,
    IN p_storeID INT
)
BEGIN
    INSERT INTO ClubMember (FirstName, LastName, MembershipLevel, Email, PhoneNumber, HomeAddress)
    VALUES (p_firstName, p_lastName, p_membershipLevel, p_email, p_phoneNumber, p_homeAddress);

    INSERT INTO SignUp (StaffID, CustomerID, Date, StoreID)
    VALUES (p_staffID, LAST_INSERT_ID(), NOW(), p_storeID);
END $$ 

DELIMITER ;

/*
===========================================================
Procedure Name : p_createCancelInfo
Create Date    : 2025-04-06
Last Modified  : 2025-04-06 
Goal           : Cancel a club member's active status and record the cancellation.
Input Params   : 
                 p_staffID INT    - ID of the staff processing the cancellation
                 p_customerID INT - ID of the customer to be cancelled
Output         : Updates ClubMember to set ActiveStatus to 0 and inserts a cancellation record into Cancel.
===========================================================
*/

DELIMITER $$
CREATE PROCEDURE p_createCancelInfo(
    IN p_staffID INT,
    IN p_customerID INT
)
MODIFIES SQL DATA
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
    END;
    
    START TRANSACTION;
    UPDATE ClubMember SET ActiveStatus = 0 WHERE CustomerID = p_customerID;

    INSERT INTO Cancel (StaffID, CustomerID, Date)
    VALUES (p_staffID, p_customerID, NOW());
    COMMIT;
END $$ 

DELIMITER ;




/*
===========================================================
Procedure Name : p_createOrders
Create Date    : 2025-04-06
Last Modified  : 2025-04-06
Goal           : Create a new order and update the store's inventory accordingly.
Input Params   : 
                 p_storeID INT(11)   - Store identifier
                 p_supplierID INT(11)- Supplier identifier
                 p_productID INT(11) - Product identifier
                 p_staffID INT(11)   - Staff identifier responsible for the order
                 p_quantity INT(11)  - Quantity ordered
                 p_price DECIMAL(10,2)- Buy price per unit
Output         : Inserts a new order in the Orders table and either updates or creates a record in Inventory.
===========================================================
*/

DELIMITER $$

CREATE PROCEDURE p_createOrders(
    IN p_storeID INT,
    IN p_supplierID INT,
    IN p_productID INT,
    IN p_staffID INT,
    IN p_quantity INT,
    IN p_price DECIMAL(10, 2)
) 
BEGIN
    DECLARE v_orderNumber BIGINT;
    DECLARE v_error_message VARCHAR(255);
    DECLARE v_error_code CHAR(5) DEFAULT '00000';
    
    -- Declare handlers for exceptions
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        GET DIAGNOSTICS CONDITION 1
        v_error_code = RETURNED_SQLSTATE, v_error_message = MESSAGE_TEXT;
        
        ROLLBACK;
        
        -- Output error information
        SELECT CONCAT('Error ', v_error_code, ': ', v_error_message) AS ErrorMessage;
    END;
    
    -- Validate input parameters
    IF p_quantity <= 0 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Quantity must be greater than 0';
    END IF;
    
    IF p_price <= 0 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Price must be greater than 0';
    END IF;
    
    -- Start transaction
    START TRANSACTION;
    
    -- Check if staff exists and is warehouse staff
    IF NOT EXISTS (SELECT 1 FROM WarehouseStaff WHERE StaffID = p_staffID) THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Staff member must be warehouse staff';
    END IF;
    
    -- Insert into Orders table
    INSERT INTO Orders (StoreID, SupplierID, ProductID, StaffID, Date, Quantity, BuyPrice)
    VALUES (p_storeID, p_supplierID, p_productID, p_staffID, NOW(), p_quantity, p_price);
    
    SET v_orderNumber = LAST_INSERT_ID();
    
    -- Check if Inventory exists and update or insert
    IF EXISTS (SELECT 1 FROM Inventory WHERE StoreID = p_storeID AND ProductID = p_productID) THEN
        UPDATE Inventory 
        SET Quantity = Quantity + p_quantity 
        WHERE StoreID = p_storeID AND ProductID = p_productID;
    ELSE
        INSERT INTO Inventory (StoreID, ProductID, Quantity, DiscountInfo, valid_from, valid_to)
        VALUES (p_storeID, p_productID, p_quantity, 0, NULL, NULL);
    END IF;

    -- Return the created order
    SELECT * FROM Orders WHERE OrderNumber = v_orderNumber;
    
    -- Commit transaction if everything succeeded
    COMMIT;
END $$

DELIMITER ;

/*
===========================================================
Procedure Name : p_createTransaction
Create Date    : 2025-04-06
Last Modified  : 2025-04-06 
Goal           : Record a sales transaction and update product inventory.
Input Params   : 
                 pStoreID INT      - Store identifier
                 pCustomerID INT   - Customer identifier
                 pCashierID INT    - Staff/cashier identifier
                 pProductID INT    - Product identifier
                 pQuantity INT     - Quantity sold
Output         : Inserts a record into the Transaction table and updates Inventory.
===========================================================
*/

DELIMITER $$
CREATE PROCEDURE p_createTransaction(
    IN pStoreID INT,
    IN pCustomerID INT,
    IN pCashierID INT,
    IN pProductID INT,
    IN pQuantity INT
)
BEGIN
    DECLARE vPrice DECIMAL(10,2);
    DECLARE vDiscount DECIMAL(10,2) DEFAULT 0;
    DECLARE vTotalPrice DECIMAL(10,2);
    DECLARE vCurrentStock INT;
    DECLARE vErrorMsg VARCHAR(255);
    DECLARE vErrorCode CHAR(5) DEFAULT '00000';
    DECLARE vStockMessage VARCHAR(100);
    
    -- Declare handler for exceptions
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        GET DIAGNOSTICS CONDITION 1
        vErrorCode = RETURNED_SQLSTATE, vErrorMsg = MESSAGE_TEXT;
        
        ROLLBACK;
        
        -- Output detailed error information
        SELECT CONCAT('Error ', vErrorCode, ': ', vErrorMsg) AS ErrorMessage;
    END;
    
    -- Start transaction
    START TRANSACTION;
    
    -- Validate input parameters
    IF pQuantity <= 0 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Quantity must be greater than 0';
    END IF;
    
    -- Verify cashier is valid and is a cashier
    IF NOT EXISTS (SELECT 1 FROM Cashier WHERE StaffID = pCashierID) THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Staff member must be a cashier';
    END IF;
    
    -- Verify customer exists and is active
    IF NOT EXISTS (SELECT 1 FROM ClubMember WHERE CustomerID = pCustomerID AND ActiveStatus = TRUE) THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Customer does not exist or is inactive';
    END IF;
    
    -- Verify product exists
    IF NOT EXISTS (SELECT 1 FROM Merchandise WHERE ProductID = pProductID) THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Product does not exist';
    END IF;
    
    -- Verify store exists
    IF NOT EXISTS (SELECT 1 FROM Store WHERE StoreID = pStoreID) THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Store does not exist';
    END IF;
    
    -- Get current price (using MarketPrice from your schema)
    SELECT MarketPrice INTO vPrice FROM Merchandise WHERE ProductID = pProductID;
    
    IF vPrice IS NULL THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Could not determine product price';
    END IF;
    
    -- Get current discount (if any valid discounts exist)
    SELECT COALESCE(DiscountInfo, 0) INTO vDiscount 
    FROM Inventory 
    WHERE StoreID = pStoreID AND ProductID = pProductID
      AND (valid_from IS NULL OR valid_from <= CURDATE())
      AND (valid_to IS NULL OR valid_to >= CURDATE())
    LIMIT 1;
    
    -- Get current stock level
    SELECT COALESCE(Quantity, 0) INTO vCurrentStock 
    FROM Inventory 
    WHERE StoreID = pStoreID AND ProductID = pProductID
    LIMIT 1;
    
    -- Check stock availability
    IF vCurrentStock < pQuantity THEN
        SET vStockMessage = CONCAT('Insufficient stock. Available: ', vCurrentStock);
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = vStockMessage;
    END IF;
    
    -- Calculate total price with discount
    SET vTotalPrice = vPrice * pQuantity * (1 - (vDiscount/100));
    
    -- Insert transaction record
    INSERT INTO `Transaction` (
        StoreID, 
        CustomerID, 
        StaffID, 
        ProductID, 
        Quantity, 
        TotalPrice, 
        PurchaseDate
    )
    VALUES (
        pStoreID, 
        pCustomerID, 
        pCashierID, 
        pProductID, 
        pQuantity, 
        vTotalPrice, 
        NOW()
    );
    
    -- Update inventory
    UPDATE Inventory 
    SET Quantity = Quantity - pQuantity 
    WHERE StoreID = pStoreID AND ProductID = pProductID;
    
    -- Return success message with transaction details
    SELECT 
        'Transaction completed successfully' AS Message,
        pStoreID AS StoreID,
        pCustomerID AS CustomerID,
        pProductID AS ProductID,
        pQuantity AS Quantity,
        vPrice AS UnitPrice,
        vDiscount AS DiscountPercent,
        vTotalPrice AS TotalAmount,
        vCurrentStock - pQuantity AS RemainingStock;
    
    COMMIT;
END $$ 

DELIMITER ;

/*
===========================================================
Procedure Name : p_createTransfer
Create Date    : 2025-04-06
Last Modified  : 2025-04-06
Goal           : Create a transfer record between two stores and update inventory accordingly.
Input Params   : 
                 p_Store1ID INT   - Source store identifier
                 p_Store2ID INT   - Destination store identifier
                 p_Product1ID INT - Product identifier in source store
                 p_Product2ID INT - Product identifier in destination store
                 p_StaffID INT    - Staff identifier processing the transfer
                 p_Quantity INT   - Quantity to be transferred
Output         : Inserts a record into Transfer and updates Inventory for both stores.
===========================================================
*/
DELIMITER $$
CREATE PROCEDURE p_createTransfer(
    IN p_Store1ID   INT,
    IN p_Store2ID   INT,
    IN p_Product1ID INT,
    IN p_Product2ID INT,
    IN p_StaffID    INT,
    IN p_Quantity   INT
)
BEGIN
    DECLARE v_TransferNumber BIGINT;
    DECLARE v_AvailableQty   INT DEFAULT 0;

    SELECT COALESCE((
        SELECT Quantity 
          FROM Inventory 
         WHERE StoreID   = p_Store1ID 
           AND ProductID = p_Product1ID
    ), 0) INTO v_AvailableQty;


    IF v_AvailableQty < p_Quantity THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Insufficient stock for transfer.';
    END IF;

    START TRANSACTION;


    INSERT INTO Transfer
        (Store1ID, Store2ID, Product1ID, Product2ID, Date, StaffID, Quantity)
    VALUES
        (p_Store1ID, p_Store2ID, p_Product1ID, p_Product2ID, NOW(), p_StaffID, p_Quantity);
    SET v_TransferNumber = LAST_INSERT_ID();


    UPDATE Inventory
       SET Quantity = Quantity - p_Quantity
     WHERE StoreID   = p_Store1ID
       AND ProductID = p_Product1ID;


    IF EXISTS (
        SELECT 1 
          FROM Inventory 
         WHERE StoreID   = p_Store2ID 
           AND ProductID = p_Product2ID
    ) THEN
        UPDATE Inventory
           SET Quantity = Quantity + p_Quantity
         WHERE StoreID   = p_Store2ID
           AND ProductID = p_Product2ID;
    ELSE
        INSERT INTO Inventory
            (StoreID, ProductID, Quantity, DiscountInfo, valid_from, valid_to)
        VALUES
            (p_Store2ID, p_Product2ID, p_Quantity, 0, NULL, NULL);
    END IF;


    SELECT v_TransferNumber AS TransferNumber;

    COMMIT;
END $$
DELIMITER ;
/*
===========================================================
Procedure Name : p_returnProduct
Create Date    : 2025-04-06
Last Modified  : 2025-04-06 
Goal           : Process a product return and update the inventory accordingly.
Input Params   : 
                 p_StoreID INT   - Store identifier
                 p_ProductID INT - Product identifier being returned
                 p_StaffID INT   - Staff identifier processing the return
                 p_Quantity INT  - Quantity being returned
                 p_customerID INT- Customer identifier for the return
Output         : Inserts a record into the Returns table and updates Inventory.
===========================================================
*/

DELIMITER $$
CREATE PROCEDURE p_returnProduct  (
    IN p_StoreID INT,
    IN p_ProductID INT,
    IN p_StaffID INT,
    IN p_Quantity INT,
    IN p_customerID INT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
    END;
    
    START TRANSACTION;
    DECLARE v_ReturnNumber BIGINT;

    INSERT INTO Returns (StoreID, ProductID, StaffID, Date, Quantity, CustomerID)
    VALUES (p_StoreID, p_ProductID, p_StaffID, CURRENT_TIMESTAMP, p_Quantity, p_customerID);
    
    SET v_ReturnNumber = LAST_INSERT_ID();
    
    UPDATE Inventory SET Quantity = Quantity + p_Quantity WHERE StoreID = p_StoreID AND ProductID = p_ProductID;
    
    SELECT * FROM Returns WHERE ReturnNumber = v_ReturnNumber;
    COMMIT;
END $$ 

DELIMITER ;
/*
===========================================================
Procedure Name : p_createRewardCheck
Create Date    : 2025-04-06
Last Modified  : 2025-04-06 
Goal           : Calculate and display the reward amount for platinum club members for a given year.
Input Params   : 
                 p_year YEAR - The year for which rewards are calculated
Output         : Returns a list of customer IDs and their total reward calculated as 2% of their total spending.
===========================================================
*/

DELIMITER $$ 
CREATE PROCEDURE p_createRewardCheck(
    IN p_year YEAR
) 
BEGIN
    SELECT c.customerID, ROUND((SUM(t.totalPrice) * 0.02), 2) AS TotalReward
    FROM Transaction AS t
    JOIN ClubMember AS c ON t.CustomerID = c.CustomerID
    WHERE c.membershipLevel = 'platinum' AND YEAR(t.PurchaseDate) = p_year
    GROUP BY c.CustomerID;
END $$ 

DELIMITER ;

/*
===========================================================
Procedure Name : p_createSupplierBill
Create Date    : 2025-04-06
Last Modified  : 2025-04-06
Goal           : Generate billing totals for each supplier based on orders for a specific year and month.
Input Params   : 
                 p_year INT - The year of interest
                 p_month INT - The month of interest
Output         : Returns each SupplierID with the calculated TotalBill.
===========================================================
*/

DELIMITER $$ 
CREATE PROCEDURE p_createSupplierBill(
    IN p_year YEAR, 
    IN p_month INT
) 
BEGIN
    SELECT s.SupplierID, SUM(o.BuyPrice * o.Quantity) AS TotalBill
    FROM Supplier AS s
    JOIN Orders AS o ON s.SupplierID = o.SupplierID
    WHERE YEAR(o.Date) = p_year AND MONTH(o.Date) = p_month
    GROUP BY s.SupplierID;
END $$ 

DELIMITER ;
/*
===========================================================
Procedure Name : p_generateSalesReport
Create Date    : 2025-04-06
Last Modified  : 2025-04-06
Goal           : Generate a sales report with variable granularity (yearly, monthly, daily or a single day).
Input Params   : 
                 pStoreID INT - Store identifier
                 pYear INT    - Year for report (0 for all years)
                 pMonth INT   - Month for report (0 if not applicable)
                 pDay INT     - Day for report (0 if not applicable)
Output         : Returns aggregated sales data based on the input parameters.
===========================================================
*/

DELIMITER $$
CREATE PROCEDURE p_generateSalesReport(
    IN pStoreID INT,
    IN pYear INT,   -- 0 means "no specific year"
    IN pMonth INT,  -- 0 means "no specific month"
    IN pDay INT     -- 0 means "no specific day"
)
BEGIN
    /*
      This procedure returns total sales (SUM(TotalPrice)) from the `Transaction` table,
      filtered by StoreID and optionally by Year, Month, Day, depending on the parameter values:
      
      1) pYear = 0  => Summarize across ALL years (group by year).
      2) pYear != 0 AND pMonth = 0 => Summarize for that year, grouped by month.
      3) pYear != 0 AND pMonth != 0 AND pDay = 0 => Summarize for that (year, month), grouped by day.
      4) pYear != 0 AND pMonth != 0 AND pDay != 0 => Summarize that single day (one row).
    */
    IF pYear = 0 THEN
        /* Case 1: pYear=0 => Summarize across ALL years (group by year) */
        SELECT YEAR(PurchaseDate) AS SalesYear, SUM(TotalPrice) AS TotalSales 
        FROM Transaction
        WHERE StoreID = pStoreID
        GROUP BY YEAR(PurchaseDate)
        ORDER BY SalesYear;
    ELSEIF pYear != 0 AND pMonth = 0 THEN
        /* Case 2: Summarize that year by month */
        SELECT MONTH(PurchaseDate) AS SalesMonth, SUM(TotalPrice) AS TotalSales 
        FROM Transaction
        WHERE StoreID = pStoreID AND YEAR(PurchaseDate) = pYear
        GROUP BY MONTH(PurchaseDate)
        ORDER BY SalesMonth;
    ELSEIF pYear != 0 AND pMonth != 0 AND pDay = 0 THEN
        /* Case 3: Summarize that (year, month) by day */
        SELECT DAY(PurchaseDate) AS SalesDay, SUM(TotalPrice) AS TotalSales
        FROM Transaction
        WHERE StoreID = pStoreID AND YEAR(PurchaseDate) = pYear AND MONTH(PurchaseDate) = pMonth
        GROUP BY DAY(PurchaseDate)
        ORDER BY SalesDay;
    ELSE
        /* Case 4: pYear != 0, pMonth != 0, pDay != 0 => Single day */
        SELECT pYear AS SalesYear, pMonth AS SalesMonth, pDay AS SalesDay, SUM(TotalPrice) AS TotalSales
        FROM Transaction
        WHERE StoreID = pStoreID AND YEAR(PurchaseDate) = pYear AND MONTH(PurchaseDate) = pMonth AND DAY(PurchaseDate) = pDay;
    END IF;
END $$ 

DELIMITER ;



/*
===========================================================
Procedure Name : p_generateSalesGrowthReport

Create Date    : 2025-04-06
Last Modified  : 2025-04-06
Goal           : Compare sales between two specified months and calculate the growth percentage.
Input Params   : 
                 p_StoreID INT  - Store identifier
                 p_Month1 VARCHAR(7) - First month in 'YYYY-MM' format
                 p_Month2 VARCHAR(7) - Second month in 'YYYY-MM' format
Output         : Returns total sales for each month along with the calculated growth rate.
===========================================================
*/

DELIMITER $$ 
CREATE PROCEDURE p_generateSalesGrowthReport(
    IN p_StoreID INT,
    IN p_Month1 VARCHAR(7),
    IN p_Month2 VARCHAR(7)
)
BEGIN
    WITH MonthlySales AS (
        SELECT DATE_FORMAT(PurchaseDate, '%Y-%m') AS SalesMonth, SUM(TotalPrice) AS Total_Sales
        FROM Transaction
        WHERE StoreID = p_StoreID
        AND (DATE_FORMAT(PurchaseDate, '%Y-%m') = p_Month1 OR DATE_FORMAT(PurchaseDate, '%Y-%m') = p_Month2)
        GROUP BY SalesMonth
    )
    SELECT 
        MAX(CASE WHEN SalesMonth = p_Month1 THEN Total_Sales END) AS Sales_Month1,
        MAX(CASE WHEN SalesMonth = p_Month2 THEN Total_Sales END) AS Sales_Month2,
        COALESCE(
            (MAX(CASE WHEN SalesMonth = p_Month2 THEN Total_Sales END) - 
             MAX(CASE WHEN SalesMonth = p_Month1 THEN Total_Sales END)) 
            / NULLIF(MAX(CASE WHEN SalesMonth = p_Month1 THEN Total_Sales END), 0) * 100, 0
        ) AS Growth_Rate
    FROM MonthlySales;
END $$ 

DELIMITER ;
/*
===========================================================
Procedure Name : p_createCustomerGrowthReportByMonth
Create Date    : 2025-04-06
Last Modified  : 2025-04-06
Goal           : Generate a report showing monthly new customer growth and calculate growth rates.
Input Params   : None
Output         : Returns monthly new customer counts, previous month counts, growth, and growth rates.
===========================================================
*/

DELIMITER $$
CREATE PROCEDURE p_createCustomerGrowthReportByMonth()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
    END;
    
    START TRANSACTION;
    CREATE TEMPORARY TABLE TempGrowthReport (
        Year INT,
        Month INT,
        NewCustomerCount INT,
        PreviousMonthCount INT DEFAULT 0,
        Growth INT DEFAULT 0,
        GrowthRate DECIMAL(10, 2) DEFAULT NULL
    );

    INSERT INTO TempGrowthReport (Year, Month, NewCustomerCount)
    SELECT
        YEAR(SignUp.Date) AS Year,
        MONTH(SignUp.Date) AS Month,
        COUNT(SignUp.CustomerID) AS NewCustomerCount
    FROM SignUp
    GROUP BY Year, Month
    ORDER BY Year, Month;

    UPDATE TempGrowthReport t1
    JOIN TempGrowthReport t2
    ON (t1.Year = t2.Year AND t1.Month = t2.Month + 1)
        OR (t1.Month = 1 AND t2.Month = 12 AND t1.Year = t2.Year + 1)
    SET t1.PreviousMonthCount = t2.NewCustomerCount,
        t1.Growth = t1.NewCustomerCount - t2.NewCustomerCount;

    UPDATE TempGrowthReport
    SET GrowthRate = CASE
        WHEN PreviousMonthCount = 0 THEN NULL
        ELSE ROUND((NewCustomerCount - PreviousMonthCount) / PreviousMonthCount * 100, 2)
    END;
    SELECT * FROM TempGrowthReport;

    DROP TEMPORARY TABLE TempGrowthReport;
    COMMIT;
END $$ 

DELIMITER ;

/*
===========================================================
Procedure Name : p_createCustomerGrowthReportByYear
Create Date    : 2025-04-06
Last Modified  : 2025-04-06
Goal           : Generate a yearly report of new customer growth with corresponding growth rates.
Input Params   : None
Output         : Returns yearly new customer counts, previous year counts, growth differences, and growth percentages.
===========================================================
*/

DELIMITER $$
CREATE PROCEDURE p_createCustomerGrowthReportByYear()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
    END;
    
    START TRANSACTION;
    CREATE TEMPORARY TABLE TempGrowthReport (
        Year INT,
        NewCustomerCount INT,
        PreviousYearCount INT DEFAULT 0,
        Growth INT DEFAULT 0,
        GrowthRate DECIMAL(10, 2) DEFAULT NULL
    );

    INSERT INTO TempGrowthReport (Year, NewCustomerCount)
    SELECT
        YEAR(SignUp.Date) AS Year,
        COUNT(SignUp.CustomerID) AS NewCustomerCount
    FROM SignUp
    GROUP BY Year
    ORDER BY Year;

    UPDATE TempGrowthReport t1
    JOIN TempGrowthReport t2
    ON t1.Year = t2.Year + 1
    SET t1.PreviousYearCount = t2.NewCustomerCount,
        t1.Growth = t1.NewCustomerCount - t2.NewCustomerCount;

    UPDATE TempGrowthReport
    SET GrowthRate = CASE
        WHEN PreviousYearCount = 0 THEN NULL
        ELSE ROUND(((NewCustomerCount - PreviousYearCount) / PreviousYearCount) * 100, 2)
    END;

    SELECT * FROM TempGrowthReport;
    DROP TEMPORARY TABLE TempGrowthReport;
    COMMIT;
END $$ 

DELIMITER ;

/*
===========================================================
Procedure Name : p_createCustomerActivityReport
Create Date    : 2025-04-06
Last Modified  : 2025-04-06
Goal           : Generate a report showing total purchase amounts per customer over a specified period.
Input Params   : 
                 p_startDate DATE - Start date of the period
                 p_endDate DATE   - End date of the period
Output         : Returns CustomerID, FirstName, LastName, and total purchase amount.
===========================================================
*/

DELIMITER $$
CREATE PROCEDURE p_createCustomerActivityReport(
   IN p_startDate DATE,
   IN p_endDate DATE
)                                
BEGIN   
    SELECT c.CustomerID, c.FirstName, c.LastName, SUM(t.TotalPrice) AS TotalPurchaseAmount
    FROM Transaction AS t 
    JOIN ClubMember AS c ON t.CustomerID = c.CustomerID
    WHERE t.PurchaseDate BETWEEN p_startDate AND p_endDate
    GROUP BY c.CustomerID;
END $$ 

DELIMITER ;

/*
===========================================================
Procedure Name : p_updateInventoryDiscount
Create Date    : 2025-04-06
Last Modified  : 2025-04-06
Goal           : Update discount details for a product in a store's inventory.
Input Params   : 
                 pStoreID INT    - Store identifier
                 pProductID INT  - Product identifier
                 pDiscount DECIMAL(10, 2) - Discount percentage (0 to 100)
                 pValidFrom DATE - Discount valid from date
                 pValidTo DATE   - Discount valid to date
Output         : Updates the Inventory record and returns the updated row.
===========================================================
*/

DELIMITER $$
CREATE PROCEDURE p_updateInventoryDiscount(
    IN p_StoreID INT,
    IN p_ProductID INT,
    IN p_Discount DECIMAL(10, 2),     -- integer between 0 and 100
    IN p_ValidFrom DATE,    -- date for discount validity
    IN p_ValidTo DATE    -- date for discount validity

)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
    END;
    
    START TRANSACTION;
    -- Optional: Validate that discount is between 0 and 100
    IF p_Discount < 0 OR p_Discount > 100 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Discount must be between 0 and 100.';
    END IF;

    -- Update the Inventory row
    UPDATE Inventory
    SET DiscountInfo = p_Discount,
        valid_from = p_ValidFrom,
        valid_to = p_ValidTo
    WHERE StoreID = p_StoreID
      AND ProductID = p_ProductID;

    -- Return the updated row
    SELECT *
    FROM Inventory
    WHERE StoreID = p_StoreID
      AND ProductID = p_ProductID;
    COMMIT;
END$$

DELIMITER ;

/*
===========================================================
Procedure Name : p_generateStoreGrossProfitReport
Create Date    : 2025-04-06
Last Modified  : 2025-04-06
Goal           : Generate a gross profit report for a store; can be detailed by product or overall.
Input Params   : 
                 store_id INT             - Store identifier
                 start_date DATE          - Start date of the report period
                 end_date DATE            - End date of the report period
                 report_detail_level VARCHAR(20) - 'product' for product-level details or 'overall' for summary
Output         : Returns gross profit, margin, and additional metrics based on detail level.
===========================================================
*/

DELIMITER //

CREATE PROCEDURE p_generateStoreGrossProfitReport(
    IN store_id INT,
    IN start_date DATE,
    IN end_date DATE,
    IN report_detail_level VARCHAR(20) -- 'product' or 'overall'
)
BEGIN
    IF report_detail_level = 'product' THEN
        -- Gross profit by product for the specified store
        SELECT 
            m.ProductID,
            m.ProductName,
            SUM(t.Quantity) AS TotalQuantitySold,
            SUM(t.TotalPrice) AS TotalRevenue,
            SUM(t.Quantity * m.BuyPrice) AS TotalCost,
            SUM(t.TotalPrice) - SUM(t.Quantity * m.BuyPrice) AS GrossProfit,
            (SUM(t.TotalPrice) - SUM(t.Quantity * m.BuyPrice)) / SUM(t.TotalPrice) * 100 AS GrossProfitMargin
        FROM 
            Transaction t
        JOIN 
            Merchandise m ON t.ProductID = m.ProductID
        WHERE 
            t.StoreID = store_id
            AND t.PurchaseDate BETWEEN start_date AND end_date
        GROUP BY 
            m.ProductID, m.ProductName
        ORDER BY 
            GrossProfit DESC;
            
    ELSE
        -- Overall gross profit for the specified store
        SELECT 
            s.StoreID,
            s.StoreAddress,
            SUM(t.TotalPrice) AS TotalRevenue,
            SUM(t.Quantity * m.BuyPrice) AS TotalCost,
            SUM(t.TotalPrice) - SUM(t.Quantity * m.BuyPrice) AS GrossProfit,
            (SUM(t.TotalPrice) - SUM(t.Quantity * m.BuyPrice)) / SUM(t.TotalPrice) * 100 AS GrossProfitMargin,
            COUNT(DISTINCT t.ProductID) AS NumberOfProductsSold,
            COUNT(DISTINCT t.CustomerID) AS NumberOfCustomers
        FROM 
            Transaction t
        JOIN 
            Merchandise m ON t.ProductID = m.ProductID
        JOIN 
            Store s ON t.StoreID = s.StoreID
        WHERE 
            t.StoreID = store_id
            AND t.PurchaseDate BETWEEN start_date AND end_date
        GROUP BY 
            s.StoreID, s.StoreAddress;
    END IF;
END //

DELIMITER ;



/*
===========================================================
Procedure Name : p_generateStoreGrossProfitGrowthReport
Create Date    : 2025-04-06
Last Modified  : 2025-04-06 
Goal           : Generate a report tracking gross profit growth for a store over a set number of periods.
Input Params   : 
                 store_id INT          - Store identifier
                 period_type VARCHAR(10) - Type of period ('monthly', 'quarterly', 'yearly')
                 num_periods INT       - Number of periods to include in the report
                 end_date DATE         - End date for the report period
Output         : Returns gross profit for each period along with the growth percentage compared to the previous period.
===========================================================
*/

DELIMITER //

CREATE PROCEDURE p_generateStoreGrossProfitGrowthReport(
    IN store_id INT,
    IN period_type VARCHAR(10), -- 'monthly', 'quarterly', or 'yearly'
    IN num_periods INT,
    IN end_date DATE
)
BEGIN
    IF period_type = 'monthly' THEN
        -- Monthly growth report for the store
        SELECT 
            DATE_FORMAT(period_start, '%Y-%m') AS Period,
            GrossProfit,
            LAG(GrossProfit) OVER (ORDER BY period_start) AS PreviousGrossProfit,
            CASE 
                WHEN LAG(GrossProfit) OVER (ORDER BY period_start) IS NULL THEN NULL
                ELSE (GrossProfit - LAG(GrossProfit) OVER (ORDER BY period_start)) / 
                     NULLIF(LAG(GrossProfit) OVER (ORDER BY period_start), 0) * 100
            END AS GrowthPercentage
        FROM (
            SELECT 
                DATE_SUB(DATE_FORMAT(end_date, '%Y-%m-01'), INTERVAL n MONTH) AS period_start,
                DATE_SUB(DATE_FORMAT(end_date, '%Y-%m-01'), INTERVAL n-1 MONTH) AS period_end,
                (
                    SELECT SUM(t.TotalPrice) - SUM(t.Quantity * m.BuyPrice)
                    FROM Transaction t
                    JOIN Merchandise m ON t.ProductID = m.ProductID
                    WHERE t.StoreID = store_id
                    AND t.PurchaseDate >= DATE_SUB(DATE_FORMAT(end_date, '%Y-%m-01'), INTERVAL n MONTH)
                    AND t.PurchaseDate < DATE_SUB(DATE_FORMAT(end_date, '%Y-%m-01'), INTERVAL n-1 MONTH)
                ) AS GrossProfit
            FROM (
                SELECT a.N AS n
                FROM (
                    SELECT 0 AS N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 
                    UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9
                    UNION SELECT 10 UNION SELECT 11 UNION SELECT 12
                ) a
                WHERE a.N < num_periods
                ORDER BY a.N
            ) numbers
        ) periods
        WHERE GrossProfit IS NOT NULL
        ORDER BY period_start;
        
    ELSEIF period_type = 'quarterly' THEN
        -- Quarterly growth report for the store
        SELECT 
            CONCAT(YEAR(period_start), '-Q', QUARTER(period_start)) AS Period,
            GrossProfit,
            LAG(GrossProfit) OVER (ORDER BY period_start) AS PreviousGrossProfit,
            CASE 
                WHEN LAG(GrossProfit) OVER (ORDER BY period_start) IS NULL THEN NULL
                ELSE (GrossProfit - LAG(GrossProfit) OVER (ORDER BY period_start)) / 
                     NULLIF(LAG(GrossProfit) OVER (ORDER BY period_start), 0) * 100
            END AS GrowthPercentage
        FROM (
            SELECT 
                DATE_SUB(DATE_FORMAT(end_date, '%Y-%m-01'), INTERVAL n*3 MONTH) AS period_start,
                DATE_SUB(DATE_FORMAT(end_date, '%Y-%m-01'), INTERVAL (n-1)*3 MONTH) AS period_end,
                (
                    SELECT SUM(t.TotalPrice) - SUM(t.Quantity * m.BuyPrice)
                    FROM Transaction t
                    JOIN Merchandise m ON t.ProductID = m.ProductID
                    WHERE t.StoreID = store_id
                    AND t.PurchaseDate >= DATE_SUB(DATE_FORMAT(end_date, '%Y-%m-01'), INTERVAL n*3 MONTH)
                    AND t.PurchaseDate < DATE_SUB(DATE_FORMAT(end_date, '%Y-%m-01'), INTERVAL (n-1)*3 MONTH)
                ) AS GrossProfit
            FROM (
                SELECT a.N AS n
                FROM (
                    SELECT 0 AS N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4
                ) a
                WHERE a.N < num_periods
                ORDER BY a.N
            ) numbers
        ) periods
        WHERE GrossProfit IS NOT NULL
        ORDER BY period_start;
        
    ELSE
        -- Yearly growth report for the store
        SELECT 
            YEAR(period_start) AS Period,
            GrossProfit,
            LAG(GrossProfit) OVER (ORDER BY period_start) AS PreviousGrossProfit,
            CASE 
                WHEN LAG(GrossProfit) OVER (ORDER BY period_start) IS NULL THEN NULL
                ELSE (GrossProfit - LAG(GrossProfit) OVER (ORDER BY period_start)) / 
                     NULLIF(LAG(GrossProfit) OVER (ORDER BY period_start), 0) * 100
            END AS GrowthPercentage
        FROM (
            SELECT 
                DATE_SUB(DATE_FORMAT(end_date, '%Y-01-01'), INTERVAL n YEAR) AS period_start,
                DATE_SUB(DATE_FORMAT(end_date, '%Y-01-01'), INTERVAL (n-1) YEAR) AS period_end,
                (
                    SELECT SUM(t.TotalPrice) - SUM(t.Quantity * m.BuyPrice)
                    FROM Transaction t
                    JOIN Merchandise m ON t.ProductID = m.ProductID
                    WHERE t.StoreID = store_id
                    AND t.PurchaseDate >= DATE_SUB(DATE_FORMAT(end_date, '%Y-01-01'), INTERVAL n YEAR)
                    AND t.PurchaseDate < DATE_SUB(DATE_FORMAT(end_date, '%Y-01-01'), INTERVAL (n-1) YEAR)
                ) AS GrossProfit
            FROM (
                SELECT a.N AS n
                FROM (
                    SELECT 0 AS N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4
                ) a
                WHERE a.N < num_periods
                ORDER BY a.N
            ) numbers
        ) periods
        WHERE GrossProfit IS NOT NULL
        ORDER BY period_start;
    END IF;
END //

DELIMITER ;