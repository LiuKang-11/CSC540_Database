/*
===========================================================
Trigger Name   : trg_after_staff_insert
Create Date    : 2025-04-09
Last Modified  : 2025-04-09
Goal           : Automatically assign newly inserted staff members 
                 to their respective role-specific tables based on JobTitle.
Trigger Timing : AFTER INSERT on Staff table
Logic Summary  : 
                 - If JobTitle is 'Manager', insert into AdminStaff
                 - If 'Assistant Manager', insert into RegistrationStaff
                 - If 'Warehouse Checker', insert into WarehouseStaff
                 - If 'Billing Staff', insert into BillingStaff
                 - If 'Cashier', insert into Cashier
===========================================================
*/

DELIMITER $$


CREATE TRIGGER trg_after_staff_insert
AFTER INSERT ON Staff
FOR EACH ROW
BEGIN
   IF NEW.JobTitle = 'Manager' THEN
       INSERT INTO AdminStaff (StaffID) VALUES (NEW.StaffID);
   ELSEIF NEW.JobTitle = 'Assistant Manager' THEN
       INSERT INTO RegistrationStaff (StaffID) VALUES (NEW.StaffID);
   ELSEIF NEW.JobTitle = 'Warehouse Checker' THEN
       INSERT INTO WarehouseStaff (StaffID) VALUES (NEW.StaffID);
   ELSEIF NEW.JobTitle = 'Billing Staff' THEN
       INSERT INTO BillingStaff (StaffID) VALUES (NEW.StaffID);
   ELSEIF NEW.JobTitle = 'Cashier' THEN
       INSERT INTO Cashier (StaffID) VALUES (NEW.StaffID);
   END IF;
END $$


DELIMITER ;