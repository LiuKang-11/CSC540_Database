package project3;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

/**
 * This class handles the updating of merchandise information.
 * It prompts the user for a ProductID and retrieves the current values from the database.
 * The user can then update the values, which are saved back to the database.
 */
public class updateMerchInfo {

    public static void updateMerchInfo() {
        Scanner scanner = new Scanner(System.in);
        
        // Get ProductID (required)
        System.out.print("Enter ProductID: ");
        int productID;
        try {
            productID = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid ProductID format. Must be a number.");
            return;
        }

        // First, get current values to show user
        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                 "SELECT ProductName, BuyPrice, MarketPrice, ProductionDate, ExpirationDate " +
                 "FROM Merchandise WHERE ProductID = ?")) {
            
            ps.setInt(1, productID);
            ResultSet rs = ps.executeQuery();
            
            if (!rs.next()) {
                System.err.println("Product with ID " + productID + " not found.");
                return;
            }
            
            // Store current values
            String currentProductName = rs.getString("ProductName");
            int currentBuyPrice = rs.getInt("BuyPrice");
            int currentMarketPrice = rs.getInt("MarketPrice");
            Date currentProductionDate = rs.getDate("ProductionDate");
            Date currentExpirationDate = rs.getDate("ExpirationDate");
            
            // Display current values
            System.out.println("\nCurrent Product Information:");
            System.out.println("1. Product Name: " + (currentProductName != null ? currentProductName : "NULL"));
            System.out.println("2. Buy Price: " + currentBuyPrice);
            System.out.println("3. Market Price: " + currentMarketPrice);
            System.out.println("4. Production Date: " + (currentProductionDate != null ? currentProductionDate : "NULL"));
            System.out.println("5. Expiration Date: " + (currentExpirationDate != null ? currentExpirationDate : "NULL"));
            System.out.println("\nEnter new values (press Enter to keep current value, type 'NULL' to set to null)");
            
            // Get updates for each field
            System.out.print("Please either enter a new value or press Enter to keep the current value.\n");
            System.out.print("Enter New Product Name [" + currentProductName + "]: ");
            String newProductName = scanner.nextLine().trim();
            if (newProductName.isEmpty()) {
                newProductName = currentProductName;
            } else if (newProductName.equalsIgnoreCase("NULL")) {
                newProductName = null;
            }

            System.out.print("Enter New Buy Price [" + currentBuyPrice + "]: ");
            String buyPriceInput = scanner.nextLine().trim();
            Integer newBuyPrice = buyPriceInput.isEmpty() ? currentBuyPrice : 
                                buyPriceInput.equalsIgnoreCase("NULL") ? null : 
                                Integer.parseInt(buyPriceInput);

            System.out.print("Enter New Market Price [" + currentMarketPrice + "]: ");
            String marketPriceInput = scanner.nextLine().trim();
            Integer newMarketPrice = marketPriceInput.isEmpty() ? currentMarketPrice : 
                                   marketPriceInput.equalsIgnoreCase("NULL") ? null : 
                                   Integer.parseInt(marketPriceInput);

            System.out.print("Enter New Production Date [" + currentProductionDate + "]: ");
            String productionDateInput = scanner.nextLine().trim();
            Date newProductionDate = productionDateInput.isEmpty() ? currentProductionDate : 
                                    productionDateInput.equalsIgnoreCase("NULL") ? null : 
                                    Date.valueOf(productionDateInput);

            System.out.print("Enter New Expiration Date [" + currentExpirationDate + "]: ");
            String expirationDateInput = scanner.nextLine().trim();
            Date newExpirationDate = expirationDateInput.isEmpty() ? currentExpirationDate : 
                                    expirationDateInput.equalsIgnoreCase("NULL") ? null : 
                                    Date.valueOf(expirationDateInput);

            // Build dynamic UPDATE statement
            StringBuilder sql = new StringBuilder("UPDATE Merchandise SET ");
            boolean first = true;
            
            if (!newProductName.equals(currentProductName)) {
                sql.append(first ? "" : ", ").append("ProductName = ?");
                first = false;
            }
            
            if (newBuyPrice != currentBuyPrice) {
                sql.append(first ? "" : ", ").append("BuyPrice = ?");
                first = false;
            }
            
            if (newMarketPrice != currentMarketPrice) {
                sql.append(first ? "" : ", ").append("MarketPrice = ?");
                first = false;
            }
            
            if (newProductionDate != currentProductionDate && 
                (newProductionDate == null || !newProductionDate.equals(currentProductionDate))) {
                sql.append(first ? "" : ", ").append("ProductionDate = ?");
                first = false;
            }
            
            if (newExpirationDate != currentExpirationDate && 
                (newExpirationDate == null || !newExpirationDate.equals(currentExpirationDate))) {
                sql.append(first ? "" : ", ").append("ExpirationDate = ?");
                first = false;
            }
            
            // If nothing changed
            if (first) {
                System.out.println("No changes detected. Nothing to update.");
                return;
            }
            
            sql.append(" WHERE ProductID = ?");
            
            // Execute the update
            try (PreparedStatement updateStmt = conn.prepareStatement(sql.toString())) {
                int paramIndex = 1;
                
                if (!newProductName.equals(currentProductName)) {
                    if (newProductName == null) {
                        updateStmt.setNull(paramIndex++, Types.VARCHAR);
                    } else {
                        updateStmt.setString(paramIndex++, newProductName);
                    }
                }
                
                if (newBuyPrice != currentBuyPrice) {
                    if (newBuyPrice == null) {
                        updateStmt.setNull(paramIndex++, Types.INTEGER);
                    } else {
                        updateStmt.setInt(paramIndex++, newBuyPrice);
                    }
                }
                
                if (newMarketPrice != currentMarketPrice) {
                    if (newMarketPrice == null) {
                        updateStmt.setNull(paramIndex++, Types.INTEGER);
                    } else {
                        updateStmt.setInt(paramIndex++, newMarketPrice);
                    }
                }
                
                if (newProductionDate != currentProductionDate && 
                    (newProductionDate == null || !newProductionDate.equals(currentProductionDate))) {
                    if (newProductionDate == null) {
                        updateStmt.setNull(paramIndex++, Types.DATE);
                    } else {
                        updateStmt.setDate(paramIndex++, newProductionDate);
                    }
                }
                
                if (newExpirationDate != currentExpirationDate && 
                    (newExpirationDate == null || !newExpirationDate.equals(currentExpirationDate))) {
                    if (newExpirationDate == null) {
                        updateStmt.setNull(paramIndex++, Types.DATE);
                    } else {
                        updateStmt.setDate(paramIndex++, newExpirationDate);
                    }
                }
                
                updateStmt.setInt(paramIndex, productID);
                
                int rowsAffected = updateStmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Successfully updated product information.");
                } else {
                    System.out.println("No rows were updated.");
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            System.err.println("Invalid date format. Please use YYYY-MM-DD format.");
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}