package project3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

/**
 * This class handles the update of supplier information.
 * It prompts the user for a SupplierID and new values for the supplier's details,
 * and updates the corresponding record in the Supplier table.
 */
public class updateSupplierInfo {

    public static void updateSupplierInfo() {
        Scanner scanner = new Scanner(System.in);
        
        // Get SupplierID (required)
        System.out.print("Enter SupplierID: ");
        int supplierID;
        try {
            supplierID = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid SupplierID format. Must be a number.");
            return;
        }

        // First, get current values to show user
        try (Connection conn = Main.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                 "SELECT Name, Location, PhoneNumber, Email " +
                 "FROM Supplier WHERE SupplierID = ?")) {
            
            ps.setInt(1, supplierID);
            ResultSet rs = ps.executeQuery();
            
            if (!rs.next()) {
                System.err.println("Supplier with ID " + supplierID + " not found.");
                return;
            }
            
            // Store current values
            String currentName = rs.getString("Name");
            String currentLocation = rs.getString("Location");
            String currentPhoneNumber = rs.getString("PhoneNumber");
            String currentEmail = rs.getString("Email");
            
            // Display current values
            System.out.println("\nCurrent Supplier Information:");
            System.out.println("1. Name: " + currentName);
            System.out.println("2. Location: " + currentLocation);
            System.out.println("3. Phone Number: " + currentPhoneNumber);
            System.out.println("4. Email: " + currentEmail);
            System.out.println("\nEnter new values (press Enter to keep current value, type 'NULL' to set to null)");
            
            // Get updates for each field
            System.out.print("Enter New Name [" + currentName + "]: ");
            String newName = scanner.nextLine().trim();
            if (newName.isEmpty()) {
                newName = currentName;
            } else if (newName.equalsIgnoreCase("NULL")) {
                System.err.println("Name cannot be NULL (it's a NOT NULL field). Keeping current value.");
                newName = currentName;
            }

            System.out.print("Enter New Location [" + currentLocation + "]: ");
            String newLocation = scanner.nextLine().trim();
            if (newLocation.isEmpty()) {
                newLocation = currentLocation;
            } else if (newLocation.equalsIgnoreCase("NULL")) {
                System.err.println("Location cannot be NULL (it's a NOT NULL field). Keeping current value.");
                newLocation = currentLocation;
            }

            System.out.print("Enter New Phone Number [" + currentPhoneNumber + "]: ");
            String newPhoneNumber = scanner.nextLine().trim();
            if (newPhoneNumber.isEmpty()) {
                newPhoneNumber = currentPhoneNumber;
            } else if (newPhoneNumber.equalsIgnoreCase("NULL")) {
                System.err.println("Phone Number cannot be NULL (it's a NOT NULL field). Keeping current value.");
                newPhoneNumber = currentPhoneNumber;
            }

            System.out.print("Enter New Email [" + currentEmail + "]: ");
            String newEmail = scanner.nextLine().trim();
            if (newEmail.isEmpty()) {
                newEmail = currentEmail;
            } else if (newEmail.equalsIgnoreCase("NULL")) {
                System.err.println("Email cannot be NULL (it's a NOT NULL field). Keeping current value.");
                newEmail = currentEmail;
            }

            // Build dynamic UPDATE statement
            StringBuilder sql = new StringBuilder("UPDATE Supplier SET ");
            boolean first = true;
            
            if (!newName.equals(currentName)) {
                sql.append(first ? "" : ", ").append("Name = ?");
                first = false;
            }
            
            if (!newLocation.equals(currentLocation)) {
                sql.append(first ? "" : ", ").append("Location = ?");
                first = false;
            }
            
            if (!newPhoneNumber.equals(currentPhoneNumber)) {
                sql.append(first ? "" : ", ").append("PhoneNumber = ?");
                first = false;
            }
            
            if (!newEmail.equals(currentEmail)) {
                sql.append(first ? "" : ", ").append("Email = ?");
                first = false;
            }
            
            // If nothing changed
            if (first) {
                System.out.println("No changes detected. Nothing to update.");
                return;
            }
            
            sql.append(" WHERE SupplierID = ?");
            
            // Execute the update
            try (PreparedStatement updateStmt = conn.prepareStatement(sql.toString())) {
                int paramIndex = 1;
                
                if (!newName.equals(currentName)) {
                    updateStmt.setString(paramIndex++, newName);
                }
                
                if (!newLocation.equals(currentLocation)) {
                    updateStmt.setString(paramIndex++, newLocation);
                }
                
                if (!newPhoneNumber.equals(currentPhoneNumber)) {
                    updateStmt.setString(paramIndex++, newPhoneNumber);
                }
                
                if (!newEmail.equals(currentEmail)) {
                    updateStmt.setString(paramIndex++, newEmail);
                }
                
                updateStmt.setInt(paramIndex, supplierID);
                
                int rowsAffected = updateStmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Successfully updated supplier information.");
                } else {
                    System.out.println("No rows were updated.");
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}